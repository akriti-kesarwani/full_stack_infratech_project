import mongoose from 'mongoose';

const woodSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Wood'
  }
}, {
  timestamps: true
});

// Add some default wood products if none exist
woodSchema.statics.initializeProducts = async function() {
  const count = await this.countDocuments();
  if (count === 0) {
    const defaultProducts = [
      { name: 'Teak Wood Planks', brand: 'GreenPly', price: '1200 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/VN/BK/CL/3823480/teak-wood-planks-500x500.jpg' },
      { name: 'Pine Wood Boards', brand: 'CenturyPly', price: '800 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/DM/EO/FP/3823480/pine-wood-boards-500x500.jpg' },
      { name: 'Oak Wood Panels', brand: 'National Ply', price: '950 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/GQ/HR/IS/3823480/oak-wood-panels-500x500.jpg' },
      { name: 'Maple Wood Sheets', brand: 'Duro Ply', price: '850 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/JT/KU/LV/3823480/maple-wood-sheets-500x500.jpg' },
      { name: 'Cedar Wood Beams', brand: 'GreenPly', price: '1100 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/MW/NX/OY/3823480/cedar-wood-beams-500x500.jpg' },
      { name: 'Mahogany Wood', brand: 'CenturyPly', price: '1300 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/PZ/QA/RB/3823480/mahogany-wood-500x500.jpg' },
      { name: 'Birch Plywood', brand: 'National Ply', price: '750 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/SC/TD/UE/3823480/birch-plywood-500x500.jpg' },
      { name: 'Walnut Wood', brand: 'Duro Ply', price: '1400 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/VF/WG/XH/3823480/walnut-wood-500x500.jpg' },
      { name: 'Bamboo Wood', brand: 'GreenPly', price: '600 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/YI/ZJ/AK/3823480/bamboo-wood-500x500.jpg' },
      { name: 'Rosewood Planks', brand: 'CenturyPly', price: '1500 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/3/BL/CM/DN/3823480/rosewood-planks-500x500.jpg' }
    ];
    await this.insertMany(defaultProducts);
  }
};

const Wood = mongoose.model('Wood', woodSchema);

export default Wood;

import mongoose from 'mongoose';

const steelSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Steel'
  }
}, {
  timestamps: true
});

// Add some default steel products if none exist
steelSchema.statics.initializeProducts = async function() {
  const count = await this.countDocuments();
  if (count === 0) {
    const defaultProducts = [
      { name: 'TMT Steel Bars', brand: 'TATA Steel', price: '750 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2021/12/QO/ZE/ER/3823480/tata-tmt-steel-bars-500x500.jpg' },
      { name: 'MS Steel Bars', brand: 'JSW Steel', price: '720 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2021/12/YD/OM/JZ/3823480/jsw-steel-bars-500x500.jpg' },
      { name: 'Steel Angles', brand: 'SAIL', price: '680 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/YU/CX/OD/3823480/steel-angles-500x500.jpg' },
      { name: 'Steel Plates', brand: 'Jindal Steel', price: '800 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/KL/MN/PQ/3823480/steel-plates-500x500.jpg' },
      { name: 'Steel Channels', brand: 'RINL', price: '700 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/RS/TU/VW/3823480/steel-channels-500x500.jpg' },
      { name: 'Steel Wire Rods', brand: 'Essar Steel', price: '650 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/XY/ZA/BC/3823480/steel-wire-rods-500x500.jpg' },
      { name: 'Steel Beams', brand: 'TATA Steel', price: '850 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/DE/FG/HI/3823480/steel-beams-500x500.jpg' },
      { name: 'Steel Sheets', brand: 'JSW Steel', price: '780 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/JK/LM/NO/3823480/steel-sheets-500x500.jpg' },
      { name: 'Steel Tubes', brand: 'SAIL', price: '600 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/PQ/RS/TU/3823480/steel-tubes-500x500.jpg' },
      { name: 'Steel Pipes', brand: 'Jindal Steel', price: '620 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/1/VW/XY/ZA/3823480/steel-pipes-500x500.jpg' }
    ];
    await this.insertMany(defaultProducts);
  }
};

const Steel = mongoose.model('Steel', steelSchema);

export default Steel;

import mongoose from 'mongoose';

const plumbingSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Plumbing'
  }
}, {
  timestamps: true
});

// Add some default plumbing products if none exist
plumbingSchema.statics.initializeProducts = async function() {
  const count = await this.countDocuments();
  if (count === 0) {
    const defaultProducts = [
      { name: 'PVC Pipes', brand: 'Supreme', price: '250 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/AO/BP/CQ/3823480/pvc-pipes-500x500.jpg' },
      { name: 'CPVC Pipes', brand: 'Astral', price: '350 Rs', image: 'http://localhost:3001/images/plumbing/Astral_Foamcore.webp' },
      { name: 'Brass Taps', brand: 'Jaguar', price: '800 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/GU/HV/IW/3823480/brass-taps-500x500.jpg' },
      { name: 'Steel Sink', brand: 'Nirali', price: '2500 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/JX/KY/LZ/3823480/steel-sink-500x500.jpg' },
      { name: 'Bathroom Fittings', brand: 'Hindware', price: '1500 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/MA/NB/OC/3823480/bathroom-fittings-500x500.jpg' },
      { name: 'Water Tank', brand: 'Sintex', price: '5000 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/PD/QE/RF/3823480/water-tank-500x500.jpg' },
      { name: 'Shower Set', brand: 'Grohe', price: '3000 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/SG/TH/UI/3823480/shower-set-500x500.jpg' },
      { name: 'Basin Mixer', brand: 'Jaquar', price: '1800 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/VJ/WK/XL/3823480/basin-mixer-500x500.jpg' },
      { name: 'Flush Tank', brand: 'Parryware', price: '2000 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/YM/ZN/AO/3823480/flush-tank-500x500.jpg' },
      { name: 'Water Heater', brand: 'Racold', price: '8000 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/4/BP/CQ/DR/3823480/water-heater-500x500.jpg' }
    ];
    await this.insertMany(defaultProducts);
  }
};

const Plumbing = mongoose.model('Plumbing', plumbingSchema);

export default Plumbing;

import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  cartItems: [{
    productId: String,
    productName: String,
    price: Number,
    quantity: Number,
    category: String,
    brand: String,
    image: String
  }],
  total: {
    type: Number,
    required: true
  },
  paymentMethod: {
    type: String,
    required: true
  },
  deliveryMethod: {
    type: String,
    required: true
  },
  paymentDetails: {
    type: Object,
    required: true
  },
  shippingAddress: {
    type: Object,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'],
    default: 'pending'
  },
  dateOrdered: {
    type: Date,
    default: Date.now
  }
});

const Order = mongoose.model('Order', orderSchema);

export default Order;

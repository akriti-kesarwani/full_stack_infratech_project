import mongoose from 'mongoose';

const cementSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Cement'
  }
}, {
  timestamps: true
});

// Add some default cement products if none exist
cementSchema.statics.initializeProducts = async function() {
  const count = await this.countDocuments();
  if (count === 0) {
    const defaultProducts = [
      { name: 'UltraTech Cement', brand: 'UltraTech', price: '350 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2020/12/ZS/DB/GU/10303963/ultratech-cement-500x500.jpg' },
      { name: 'ACC Cement', brand: 'ACC', price: '340 Rs', image: 'https://5.imimg.com/data5/RV/FQ/NU/ANDROID-29945076/product-jpeg.jpg' },
      { name: 'Ambuja Cement', brand: 'Ambuja', price: '330 Rs', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNdVY3Yg1iWqBRYTaWz2ZcHKLNgRXkrHZbYA&s' },
      { name: 'Shree Cement', brand: 'Shree', price: '320 Rs', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSr2vVNzvvdUbSE3cxrHgs2IG9a02g6BY7JgblcoMtY6jKuk7xNGjC9QY5RuSGKPwKepTk&usqp=CAU' },
      { name: 'Dalmia Cement', brand: 'Dalmia', price: '310 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2023/3/ZN/RS/SK/28002835/dalmia-cement-250x250.jpg' },
      { name: 'Birla Cement', brand: 'Birla', price: '315 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2021/1/YJ/JE/TC/120617325/birla-a1-premium-cement.jpg' },
      { name: 'Jaypee Cement', brand: 'Jaypee', price: '325 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2020/10/PB/VQ/FO/114957080/jp-cement-500x500.PNG' },
      { name: 'JK Cement', brand: 'JK', price: '335 Rs', image: 'https://buildmakaan.in/wp-content/uploads/2021/12/jk-super-opc-buildmakaan.in_.png' },
      { name: 'Wonder Cement', brand: 'Wonder', price: '340 Rs', image: 'https://www.wondercement.com/images/ppc_left.webp' },
      { name: 'Ramco Cement', brand: 'Ramco', price: '345 Rs', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzUbaarXDm1MFfDTppv2dx4ihkw4xMNybJkA&s' }
    ];
    await this.insertMany(defaultProducts);
  }
};

const Cement = mongoose.model('Cement', cementSchema);

export default Cement;

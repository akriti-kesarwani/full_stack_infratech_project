import mongoose from 'mongoose';

const sandSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: 'Sand'
  }
}, {
  timestamps: true
});

// Add some default sand products if none exist
sandSchema.statics.initializeProducts = async function() {
  const count = await this.countDocuments();
  if (count === 0) {
    const defaultProducts = [
      { name: 'River Sand', brand: 'Natural Sand Co', price: '2800 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/AS/BT/CU/3823480/river-sand-500x500.jpg' },
      { name: 'M Sand', brand: 'Manufactured Sand', price: '2500 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/DV/EW/FX/3823480/m-sand-500x500.jpg' },
      { name: 'Plastering Sand', brand: 'Construction Sand', price: '2600 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/GY/HZ/IA/3823480/plastering-sand-500x500.jpg' },
      { name: 'Filling Sand', brand: 'Fill Sand Co', price: '2200 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/JB/KC/LD/3823480/filling-sand-500x500.jpg' },
      { name: 'Concrete Sand', brand: 'Concrete Mix Co', price: '2700 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/ME/NF/OG/3823480/concrete-sand-500x500.jpg' },
      { name: 'Silica Sand', brand: 'Silica Pro', price: '3000 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/PH/QI/RJ/3823480/silica-sand-500x500.jpg' },
      { name: 'Coarse Sand', brand: 'Coarse Mix Co', price: '2900 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/SK/TL/UM/3823480/coarse-sand-500x500.jpg' },
      { name: 'Fine Sand', brand: 'Fine Sand Co', price: '2400 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/VN/WO/XP/3823480/fine-sand-500x500.jpg' },
      { name: 'Washed Sand', brand: 'Clean Sand Co', price: '3100 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/YQ/ZR/AS/3823480/washed-sand-500x500.jpg' },
      { name: 'Construction Sand', brand: 'Build Sand Co', price: '2650 Rs', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/BT/CU/DV/3823480/construction-sand-500x500.jpg' }
    ];
    await this.insertMany(defaultProducts);
  }
};

const Sand = mongoose.model('Sand', sandSchema);

export default Sand;

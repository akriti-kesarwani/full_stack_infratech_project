import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

// Define User Schema
const UserSchema = new mongoose.Schema({
  firstName: { type: String, required: true, trim: true, minlength: 2 },
  lastName: { type: String, required: true, trim: true, minlength: 2 },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    match: /.+\@.+\..+/,
  },
  password: { type: String, required: true, minlength: 6 },
});

// Hash the password before saving
UserSchema.pre('save', async function (next) {
  console.log('Pre-save middleware triggered');
  if (!this.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    console.log('Password hashed successfully');
    next();
  } catch (error) {
    console.error('Error hashing password:', error);
    next(error);
  }
});

const User = mongoose.model('User', UserSchema);

// MongoDB Connection
const connectDB = async () => {
  try {
    console.log('Attempting to connect to MongoDB...');
    await mongoose.connect('mongodb://localhost:27017/yourDatabase', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
    });
    console.log('MongoDB connected successfully!');
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    process.exit(1);
  }
};

connectDB();

// Test Saving a User
const testUser = async () => {
  try {
    const existingUser = await User.findOne({ email: 'johndoe@example.com' });
    if (existingUser) {
      console.log('Email already exists');
      return;
    }

    const newUser = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'johndoe@example.com',
      password: 'password123',
    });

    await newUser.save();
    console.log('User created successfully!');
  } catch (error) {
    console.error('Error saving user:', error.message);
  }
};

testUser();

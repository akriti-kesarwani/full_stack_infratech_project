import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import admin from 'firebase-admin';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import notificationsRouter from './routes/notifications.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Initialize Firebase Admin
const serviceAccount = JSON.parse(
  fs.readFileSync(join(__dirname, 'firebase-service-account.json'), 'utf8')
);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const app = express();
const port = 3002; // Using a different port to avoid conflicts

app.use(cors());
app.use(express.json());

// Use the notifications router
app.use('/api/notifications', notificationsRouter);

// Basic test endpoint
app.get('/test', (req, res) => {
  res.json({ message: 'Notification server is running' });
});

// Start server
app.listen(port, () => {
  console.log(`Notification server is running on port ${port}`);
});

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { fileURLToPath } from 'url';
import path from 'path';
import { dirname } from 'path';
import fs from 'fs';
import User from './models/User.js';
import CartItem from './models/CartItem.js';
import Order from './models/Order.js';
import Cement from './models/Cement.js';
import Steel from './models/Steel.js';
import Wood from './models/Wood.js';
import Plumbing from './models/Plumbing.js';
import Sand from './models/Sand.js';
import notificationsRouter from './routes/notifications.js';
import connectDB from './config/db.js';
import admin from 'firebase-admin';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = 5001; // Changed port to 5001

// Connect to MongoDB with updated options
mongoose.connect('mongodb://127.0.0.1:27017/infratrack', {
  family: 4
}).then(() => {
  console.log('MongoDB Connected Successfully');
  
  // Start the server only after MongoDB is connected
  const server = app.listen(PORT, '127.0.0.1', () => {
    console.log(`Server is running on http://127.0.0.1:${PORT}`);
    console.log('Press Ctrl+C to stop the server');
  }).on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use. Please try a different port or kill the process using this port.`);
      process.exit(1);
    } else {
      console.error('Server error:', err);
      process.exit(1);
    }
  });

  // Handle process termination
  process.on('SIGTERM', () => {
    console.log('SIGTERM received. Closing server...');
    server.close(() => {
      console.log('Server closed');
      mongoose.connection.close(false, () => {
        console.log('MongoDB connection closed');
        process.exit(0);
      });
    });
  });

}).catch(err => {
  console.error('MongoDB connection error:', err);
  process.exit(1);
});

// CORS configuration
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Accept', 'Authorization']
}));

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb', parameterLimit: 10000 }));
app.use(express.static('public'));
app.use('/images', express.static(path.join(__dirname, 'models/images')));

// Debug middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    services: {
      server: 'running',
      database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
    }
  });
});

// API Routes
app.get('/api/status', (req, res) => {
  res.json({ status: 'ok' });
});

// Initialize products
const initializeProducts = async () => {
  try {
    await Cement.initializeProducts();
    await Steel.initializeProducts();
    await Wood.initializeProducts();
    await Plumbing.initializeProducts();
    await Sand.initializeProducts();
    console.log('All products initialized');
  } catch (error) {
    console.error('Error initializing products:', error);
  }
};

// Add debug middleware to log all requests
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  console.log('Request headers:', req.headers);
  if (req.body && Object.keys(req.body).length > 0) {
    console.log('Request body:', req.body);
  }
  next();
});

// Cart Routes
app.get('/api/cart', async (req, res) => {
  try {
    console.log('Fetching cart items...');
    const cartItems = await CartItem.find().sort({ dateAdded: -1 });
    const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    console.log('Cart items:', cartItems);
    console.log('Total:', total);
    res.json({ success: true, cart: cartItems, total });
  } catch (error) {
    console.error('Error fetching cart:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch cart items' });
  }
});

app.get('/api/cart/count', async (req, res) => {
  try {
    console.log('Fetching cart count...');
    const count = await CartItem.countDocuments();
    console.log('Cart count:', count);
    res.json({ success: true, count });
  } catch (error) {
    console.error('Error getting cart count:', error);
    res.status(500).json({ success: false, message: 'Failed to get cart count' });
  }
});

app.post('/api/cart/add', async (req, res) => {
  try {
    console.log('Adding item to cart:', req.body);
    const { productId, productName, price, quantity = 1, category, brand, image } = req.body;

    // Validate required fields
    if (!productId || !productName || !price || !category || !brand || !image) {
      console.log('Missing required fields:', { productId, productName, price, category, brand, image });
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields for cart item'
      });
    }

    // Validate price is a number
    if (isNaN(price) || price <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid price value'
      });
    }

    // Check if item already exists in cart
    let cartItem = await CartItem.findOne({ productId: productId });
    console.log('Existing cart item:', cartItem);

    if (cartItem) {
      // Update existing item
      cartItem.quantity += quantity;
      await cartItem.save();
      console.log('Updated cart item:', cartItem);
      res.json({ 
        success: true, 
        message: 'Cart item quantity updated',
        cartItem 
      });
    } else {
      // Create new cart item
      cartItem = new CartItem({
        productId,
        productName,
        price,
        quantity,
        category,
        brand,
        image,
        dateAdded: new Date()
      });
      await cartItem.save();
      console.log('Created new cart item:', cartItem);
      res.json({ 
        success: true, 
        message: 'Item added to cart',
        cartItem 
      });
    }
  } catch (error) {
    console.error('Error adding item to cart:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to add item to cart',
      error: error.message 
    });
  }
});

app.delete('/api/cart/remove/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    console.log('Removing item from cart:', productId);
    
    const result = await CartItem.findOneAndDelete({ productId });
    if (!result) {
      return res.status(404).json({ 
        success: false, 
        message: 'Item not found in cart' 
      });
    }
    
    res.json({ 
      success: true, 
      message: 'Item removed from cart',
      removedItem: result
    });
  } catch (error) {
    console.error('Error removing item from cart:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to remove item from cart',
      error: error.message 
    });
  }
});

app.put('/api/cart/update', async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    
    if (!productId || !quantity || quantity < 1) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid product ID or quantity' 
      });
    }
    
    const cartItem = await CartItem.findOne({ productId });
    if (!cartItem) {
      return res.status(404).json({ 
        success: false, 
        message: 'Item not found in cart' 
      });
    }
    
    cartItem.quantity = quantity;
    await cartItem.save();
    
    res.json({ 
      success: true, 
      message: 'Cart item updated',
      cartItem 
    });
  } catch (error) {
    console.error('Error updating cart item:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to update cart item',
      error: error.message 
    });
  }
});

app.post('/api/cart/checkout', async (req, res) => {
  try {
    const { items, total, paymentMethod, deliveryMethod, shippingAddress, paymentDetails } = req.body;

    // Validate request
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Cart is empty' });
    }

    if (!paymentMethod || !deliveryMethod) {
      return res.status(400).json({ success: false, message: 'Payment method and delivery method are required' });
    }

    if (!shippingAddress || !shippingAddress.street || !shippingAddress.city || 
        !shippingAddress.state || !shippingAddress.pincode || !shippingAddress.phone) {
      return res.status(400).json({ success: false, message: 'Complete shipping address is required' });
    }

    // Validate payment details based on method
    if (paymentMethod === 'bank' && (!paymentDetails.accountNumber || !paymentDetails.ifsc)) {
      return res.status(400).json({ success: false, message: 'Bank details are incomplete' });
    }
    if (paymentMethod === 'card' && (!paymentDetails.cardNumber || !paymentDetails.expiryDate || !paymentDetails.cvv)) {
      return res.status(400).json({ success: false, message: 'Card details are incomplete' });
    }
    if (paymentMethod === 'upi' && !paymentDetails.upiId) {
      return res.status(400).json({ success: false, message: 'UPI ID is required' });
    }

    // Create order
    const order = new Order({
      items: items.map(item => ({
        productId: item.productId,
        productName: item.productName,
        price: item.price,
        quantity: item.quantity,
        category: item.category,
        brand: item.brand
      })),
      total,
      paymentMethod,
      deliveryMethod,
      shippingAddress,
      paymentDetails,
      status: 'pending',
      orderDate: new Date()
    });

    await order.save();

    // Clear the cart after successful order
    await CartItem.deleteMany({});

    res.json({ 
      success: true, 
      message: 'Order placed successfully', 
      orderId: order._id 
    });

  } catch (error) {
    console.error('Checkout error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to process checkout',
      error: error.message 
    });
  }
});

// Authentication Routes
app.post('/api/auth/signup', async (req, res) => {
  try {
    console.log('Signup request received:', req.body);
    const { firstName, lastName, email, password } = req.body;

    // Validate required fields
    if (!firstName || !lastName || !email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields are required' 
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please enter a valid email address' 
      });
    }

    // Validate password strength
    if (password.length < 8) {
      return res.status(400).json({ 
        success: false, 
        message: 'Password must be at least 8 characters long' 
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ 
        success: false, 
        message: 'An account with this email already exists' 
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create new user
    const user = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword
    });

    await user.save();
    console.log('User saved successfully:', user);

    // Create JWT token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Error in signup:', error);
    res.status(500).json({ 
      success: false, 
      message: 'An error occurred while creating your account. Please try again.' 
    });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Invalid credentials' });
    }

    // Create JWT token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Error in login:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Middleware to protect routes
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ success: false, message: 'No token, authorization denied' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Token is not valid' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ success: false, message: 'Token is not valid' });
  }
};

// Product Routes
app.get('/api/cement', async (req, res) => {
  try {
    const products = await Cement.find().sort({ name: 1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching cement products:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch cement products' });
  }
});

app.get('/api/steel', async (req, res) => {
  try {
    const products = await Steel.find().sort({ name: 1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching steel products:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch steel products' });
  }
});

app.get('/api/wood', async (req, res) => {
  try {
    const products = await Wood.find().sort({ name: 1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching wood products:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch wood products' });
  }
});

app.get('/api/plumbing', async (req, res) => {
  try {
    const products = await Plumbing.find().sort({ name: 1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching plumbing products:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch plumbing products' });
  }
});

app.get('/api/sand', async (req, res) => {
  try {
    const products = await Sand.find().sort({ name: 1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching sand products:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch sand products' });
  }
});

app.use('/api/notifications', notificationsRouter);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Handle 404 errors
app.use((req, res) => {
  console.log('404 Not Found:', req.method, req.url);
  res.status(404).json({
    success: false,
    message: 'Endpoint not found'
  });
});

// Initialize Firebase Admin
const serviceAccount = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'firebase-service-account.json'), 'utf8')
);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

import express from 'express';
import User from '../models/User.js';
import Product from '../models/Product.js';
import auth from './middleware/auth.js';

const router = express.Router();

// Add item to cart
router.post('/add', auth, async (req, res) => {
  const { productId } = req.body;
  const userId = req.user.id;
  
  try {
    const user = await User.findById(userId);
    const product = await Product.findById(productId);

    if (!user || !product) {
      return res.status(404).json({ success: false, message: 'User or Product not found' });
    }

    // Check if the product already exists in the cart
    const existingProduct = user.cart.find(
      (item) => item.productId.toString() === productId
    );

    if (existingProduct) {
      existingProduct.quantity += 1; // Increment quantity if product is already in cart
    } else {
      user.cart.push({ productId, quantity: 1 }); // Add new product to cart
    }

    await user.save();
    res.status(200).json({ success: true, message: 'Product added to cart' });
  } catch (err) {
    console.error('Error adding to cart:', err);
    res.status(500).json({ success: false, message: 'Error adding to cart' });
  }
});

// Update cart item quantity
router.put('/update', auth, async (req, res) => {
  const { productId, quantity } = req.body;
  const userId = req.user.id;
  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const cartItem = user.cart.find(item => item.productId.toString() === productId);
    if (!cartItem) {
      return res.status(404).json({ success: false, message: 'Product not found in cart' });
    }

    cartItem.quantity = quantity;
    await user.save();

    res.status(200).json({ success: true, message: 'Cart updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Remove item from cart
router.delete('/remove/:productId', auth, async (req, res) => {
  const { productId } = req.params;
  const userId = req.user.id;
  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    user.cart = user.cart.filter(item => item.productId.toString() !== productId);
    await user.save();

    res.status(200).json({ success: true, message: 'Item removed from cart' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get cart items
router.get('/items', auth, async (req, res) => {
  const userId = req.user.id;
  try {
    const user = await User.findById(userId)
      .populate('cart.productId');
    
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const cartItems = user.cart.map(item => ({
      productId: item.productId._id,
      productName: item.productId.name,
      brand: item.productId.brand,
      price: item.productId.price * item.quantity,
      quantity: item.quantity,
      image: item.productId.image
    }));

    res.status(200).json({ success: true, cart: cartItems });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get cart count for the user
router.get('/cart-count', auth, async (req, res) => {
  const userId = req.user.id;
  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    const cartCount = user.cart.length;
    res.status(200).json({ success: true, count: cartCount });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get cart count
router.get('/count', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const count = user.cart.reduce((total, item) => total + item.quantity, 0);
    res.json({ success: true, count });
  } catch (err) {
    console.error('Error getting cart count:', err);
    res.status(500).json({ success: false, message: 'Error getting cart count' });
  }
});

export default router;

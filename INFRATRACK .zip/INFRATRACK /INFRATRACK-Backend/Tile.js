import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Tile = () => {
  const [cartCount, setCartCount] = useState(0);

  const tileProducts = [
    { name: 'Ceramic Tile', brand: 'Ceramic', price: '200 Rs', image: 'https://images.orientbell.com/media/catalog/product/c/r/craftclad_mosaic_4x8_grey_1.jpg', _id: '1' },
    { name: 'Porcelain Tile', brand: 'Porcelain', price: '250 Rs', image: 'https://www.deltaware.in//images/product/tiles-floor-1x1-matte_hu81e986848479647bc73125b0948b2562_59143_600x600_resize_q50_box.jpg', _id: '2' },
    // More products here...
  ];

  useEffect(() => {
    const fetchCartCount = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/cart/cart-count?userId=USER_ID');
        setCartCount(response.data.count);
      } catch (error) {
        console.error('Error fetching cart count:', error);
      }
    };
    fetchCartCount();
  }, []);

  const handleAddToCart = async (product) => {
    try {
      const userId = 'USER_ID'; // Replace with the logged-in user's ID dynamically
      await axios.post('http://localhost:5000/api/cart/add-to-cart', { userId, productId: product._id });
      setCartCount(prevCount => prevCount + 1); // Update cart count locally
    } catch (error) {
      console.error('Error adding item to cart:', error);
    }
  };

  return (
    <div>
      <h1>Tile Products</h1>
      <nav>
        <Link to="/cart">
          <i className="fa fa-shopping-cart"></i> Cart ({cartCount})
        </Link>
      </nav>
      <div>
        {tileProducts.map((product) => (
          <div key={product._id}>
            <img src={product.image} alt={product.name} />
            <h2>{product.name}</h2>
            <p>Brand: {product.brand}</p>
            <p>Price: {product.price}</p>
            <button onClick={() => handleAddToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Tile;

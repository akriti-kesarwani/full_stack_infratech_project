import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from './models/User.js';

const app = express();
const PORT = process.env.PORT || 5001;

// Basic middleware
app.use(express.json());
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true
}));

// Debug middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Cart Schema
const cartSchema = new mongoose.Schema({
  productId: String,
  productName: String,
  price: Number,
  quantity: Number,
  category: String,
  brand: String,
  image: String
});

const Cart = mongoose.model('Cart', cartSchema);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok',
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// Cart endpoints
app.get('/api/cart', async (req, res) => {
  try {
    const items = await Cart.find();
    res.json({
      success: true,
      items
    });
  } catch (error) {
    console.error('Error getting cart items:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get cart items'
    });
  }
});

app.get('/api/cart/count', async (req, res) => {
  try {
    const count = await Cart.countDocuments();
    res.json({
      success: true,
      count
    });
  } catch (error) {
    console.error('Error getting cart count:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get cart count'
    });
  }
});

app.post('/api/cart/add', async (req, res) => {
  try {
    console.log('Received cart item:', req.body);
    const cartItem = new Cart(req.body);
    await cartItem.save();
    
    const cartCount = await Cart.countDocuments();
    
    res.json({
      success: true,
      message: 'Item added to cart successfully',
      cartCount
    });
  } catch (error) {
    console.error('Error adding item to cart:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add item to cart'
    });
  }
});

app.post('/api/cart/remove', async (req, res) => {
  try {
    const { productId } = req.body;
    await Cart.findOneAndDelete({ productId });
    
    const cartCount = await Cart.countDocuments();
    
    res.json({
      success: true,
      message: 'Item removed from cart successfully',
      cartCount
    });
  } catch (error) {
    console.error('Error removing item from cart:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove item from cart'
    });
  }
});

app.post('/api/cart/update', async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    await Cart.findOneAndUpdate({ productId }, { quantity });
    
    res.json({
      success: true,
      message: 'Cart updated successfully'
    });
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update cart'
    });
  }
});

app.delete('/api/cart/clear', async (req, res) => {
  try {
    await Cart.deleteMany({});
    res.json({
      success: true,
      message: 'Cart cleared successfully'
    });
  } catch (error) {
    console.error('Error clearing cart:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to clear cart'
    });
  }
});

// Signup endpoint
app.post('/api/auth/signup', async (req, res) => {
  try {
    console.log('Received signup request:', req.body);
    const { firstName, lastName, email, password } = req.body;

    // Validate input
    if (!firstName || !lastName || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required'
      });
    }

    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword
    });

    await user.save();
    console.log('User created:', user);

    // Generate token
    const token = jwt.sign(
      { userId: user._id },
      'your-secret-key',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during signup'
    });
  }
});

// Notification endpoints
app.post('/api/notifications/test', async (req, res) => {
  try {
    const { token } = req.body;
    console.log('Received test notification request for token:', token);
    
    // For now, just return success
    res.json({ 
      success: true, 
      message: 'Test notification endpoint reached successfully' 
    });
  } catch (error) {
    console.error('Test notification error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error sending test notification' 
    });
  }
});

app.post('/api/notifications/register', async (req, res) => {
  try {
    const { token, userId } = req.body;
    console.log('Registering notification token for user:', userId);
    
    // For now, just return success
    res.json({ 
      success: true, 
      message: 'Notification token registered successfully' 
    });
  } catch (error) {
    console.error('Token registration error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error registering notification token' 
    });
  }
});

app.post('/api/notifications/send', async (req, res) => {
  try {
    const { token, title, body } = req.body;
    console.log('Sending notification:', { token, title, body });
    
    // For now, just return success
    res.json({ 
      success: true, 
      message: 'Notification sent successfully' 
    });
  } catch (error) {
    console.error('Send notification error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error sending notification' 
    });
  }
});

// Connect to MongoDB and start server
async function startServer() {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/infratrack');
    console.log('Connected to MongoDB');

    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle process termination
process.on('SIGINT', async () => {
  try {
    await mongoose.connection.close();
    console.log('MongoDB connection closed');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
});

startServer();

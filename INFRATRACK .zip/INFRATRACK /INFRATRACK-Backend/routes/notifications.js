import express from 'express';
import admin from 'firebase-admin';

const router = express.Router();

// Register FCM token
router.post('/register', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'FCM token is required' });
    }
    
    console.log('Registering token:', token);
    res.json({ success: true, message: 'Token registered successfully' });
  } catch (error) {
    console.error('Error registering token:', error);
    res.status(500).json({ error: 'Failed to register token' });
  }
});

// Test notification endpoint
router.post('/test', async (req, res) => {
  try {
    const { token } = req.body;
    console.log('Received test request with token:', token);

    if (!token) {
      return res.status(400).json({ error: 'FCM token is required' });
    }

    const message = {
      token: token,
      data: {
        title: 'Test Notification',
        body: 'This is a test notification from InfraTrack',
        click_action: 'VIEW_CART',
        url: '/cart'
      }
    };

    console.log('Sending test message:', message);
    const response = await admin.messaging().send(message);
    console.log('Test message sent successfully:', response);
    
    res.json({ success: true, messageId: response });
  } catch (error) {
    console.error('Error sending test notification:', error);
    res.status(500).json({ error: error.message });
  }
});

// Send notification endpoint
router.post('/send', async (req, res) => {
  try {
    const { token, notification } = req.body;
    console.log('Received notification request:', { token, notification });

    if (!token || !notification) {
      return res.status(400).json({ 
        error: 'Both FCM token and notification object are required',
        received: { token: !!token, notification: !!notification }
      });
    }

    if (!notification.title || !notification.body) {
      return res.status(400).json({ 
        error: 'Notification must include both title and body',
        received: notification
      });
    }

    const message = {
      token: token,
      data: {
        title: notification.title,
        body: notification.body,
        click_action: 'VIEW_CART',
        url: '/cart',
        type: 'cart_notification',
        requireInteraction: 'true',
        actions: JSON.stringify([
          {
            action: 'view',
            title: 'View Cart'
          }
        ])
      }
    };

    console.log('Sending message:', message);
    const response = await admin.messaging().send(message);
    console.log('Message sent successfully:', response);
    
    res.json({ success: true, messageId: response });
  } catch (error) {
    console.error('Error sending notification:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;

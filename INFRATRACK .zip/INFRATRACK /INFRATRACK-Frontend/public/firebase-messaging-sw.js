/* eslint-disable no-undef */
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js');

const firebaseConfig = {
  apiKey: "AIzaSyCkpB55G3sYiLAxs8ruB4FaJU0KyOy5AkQ",
  authDomain: "infra-market-f8717.firebaseapp.com",
  projectId: "infra-market-f8717",
  storageBucket: "infra-market-f8717.firebasestorage.app",
  messagingSenderId: "380229231890",
  appId: "1:380229231890:web:489d79263d0277d05a7fcb",
  measurementId: "G-YB1JLGCRTP"
};

let messaging;

try {
  firebase.initializeApp(firebaseConfig);
  messaging = firebase.messaging();
  console.log('Firebase initialized in service worker');
} catch (error) {
  console.error('Error initializing Firebase in service worker:', error);
}

// Handle background messages
messaging.onBackgroundMessage((payload) => {
  console.log('Received background message:', payload);

  // For data messages, create notification from data
  const notificationTitle = payload.data.title || 'New Notification';
  const notificationOptions = {
    body: payload.data.body,
    icon: '/logo192.png',
    badge: '/logo192.png',
    tag: 'cart-notification',
    data: payload.data,
    requireInteraction: payload.data.requireInteraction === 'true',
    actions: payload.data.actions ? JSON.parse(payload.data.actions) : [
      {
        action: 'view',
        title: 'View Cart'
      }
    ]
  };

  console.log('Showing notification with options:', notificationOptions);

  self.registration.showNotification(notificationTitle, notificationOptions)
    .then(() => {
      console.log('Notification shown successfully');
    })
    .catch(error => {
      console.error('Error showing notification:', error);
    });
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  console.log('Notification clicked:', event);

  const notification = event.notification;
  const action = event.action;
  const data = notification.data || {};
  const url = data.url || '/cart';

  notification.close();

  // Handle both action click and notification click
  if (action === 'view' || !action) {
    event.waitUntil(
      clients.matchAll({ type: 'window', includeUncontrolled: true })
        .then(windowClients => {
          // Check if there is already a window/tab open with the target URL
          for (let client of windowClients) {
            if (client.url.includes(url) && 'focus' in client) {
              return client.focus();
            }
          }
          // If no window/tab is open, open a new one
          return clients.openWindow(url);
        })
        .catch(error => {
          console.error('Error handling notification click:', error);
        })
    );
  }
});

import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyCkpB55G3sYiLAxs8ruB4FaJU0KyOy5AkQ",
  authDomain: "infra-market-f8717.firebaseapp.com",
  projectId: "infra-market-f8717",
  storageBucket: "infra-market-f8717.firebasestorage.app",
  messagingSenderId: "380229231890",
  appId: "1:380229231890:web:489d79263d0277d05a7fcb",
  measurementId: "G-YB1JLGCRTP"
};

let messaging = null;
let app = null;

// Initialize Firebase only if it hasn't been initialized yet
if (!app) {
  try {
    app = initializeApp(firebaseConfig);
    messaging = getMessaging(app);
    console.log('Firebase initialized successfully');
  } catch (error) {
    console.error('Error initializing Firebase:', error);
  }
}

export const requestNotificationPermission = async () => {
  if (!messaging) {
    console.error('Firebase messaging not initialized');
    return null;
  }

  try {
    console.log('Checking notification permission...');
    let permission = Notification.permission;
    
    if (permission === 'default') {
      console.log('Requesting permission...');
      permission = await Notification.requestPermission();
    }
    
    console.log('Permission:', permission);
    
    if (permission === 'granted') {
      try {
        console.log('Getting token with vapidKey...');
        const token = await getToken(messaging, { 
          vapidKey: "BEcp8f4qJugSu4DOml9aDicSyC2glJjGhbL4KyfgIKhyBGhEQO2Oj3jsn4Xe3elhL3b0kN8xxVz7VCKBR-uuDpE" 
        });
        
        if (!token) {
          console.error('No registration token available');
          return null;
        }

        console.log('FCM Token:', token);
        return token;
      } catch (tokenError) {
        console.error('Error getting token:', tokenError);
        return null;
      }
    } else {
      console.log('Permission denied or dismissed');
      return null;
    }
  } catch (error) {
    console.error('Error in notification permission flow:', error);
    return null;
  }
};

export const onMessageListener = () => {
  if (!messaging) {
    console.error('Firebase messaging not initialized');
    return Promise.reject('Firebase messaging not initialized');
  }

  return new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      console.log('Received foreground message:', payload);

      // Show notification for foreground messages
      if (payload.data) {
        const notificationTitle = payload.data.title;
        const notificationOptions = {
          body: payload.data.body,
          icon: '/logo192.png',
          badge: '/logo192.png',
          tag: 'cart-notification',
          requireInteraction: true,
          actions: payload.data.actions ? JSON.parse(payload.data.actions) : [
            {
              action: 'view',
              title: 'View Cart'
            }
          ],
          data: payload.data
        };

        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.ready.then(registration => {
            registration.showNotification(notificationTitle, notificationOptions)
              .then(() => console.log('Foreground notification shown'))
              .catch(error => console.error('Error showing foreground notification:', error));
          });
        }
      }

      resolve(payload);
    });
  });
};
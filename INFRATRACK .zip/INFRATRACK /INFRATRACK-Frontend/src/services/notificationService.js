import axios from 'axios';
import { requestNotificationPermission, onMessageListener } from '../firebase/config';

const NOTIFICATION_SERVER = 'http://localhost:3002/api/notifications';

export const sendCartNotification = async (product) => {
  try {
    console.log('Sending notification for product:', product.name);

    // Get FCM token
    const token = await requestNotificationPermission();
    if (!token) {
      console.error('No FCM token available');
      return false;
    }

    // Send notification
    console.log('Using endpoint:', `${NOTIFICATION_SERVER}/send`);
    const response = await axios.post(`${NOTIFICATION_SERVER}/send`, {
      token,
      notification: {
        title: 'Product Added to Cart',
        body: `${product.name} has been added to your cart`,
        tag: 'cart-notification',
        requireInteraction: true
      }
    });

    console.log('Notification sent successfully:', response.data);
    return true;
  } catch (error) {
    console.error('Error sending notification:', error);
    return false;
  }
};

export const testNotification = async () => {
  try {
    const token = await requestNotificationPermission();
    if (!token) {
      console.error('No FCM token available');
      return false;
    }

    const response = await axios.post(`${NOTIFICATION_SERVER}/test`, {
      token
    });

    console.log('Test notification sent successfully:', response.data);
    return true;
  } catch (error) {
    console.error('Error sending test notification:', error);
    return false;
  }
};

// Set up foreground message listener
onMessageListener()
  .then(payload => {
    console.log('Foreground message received:', payload);
  })
  .catch(err => console.error('Error setting up message listener:', err));

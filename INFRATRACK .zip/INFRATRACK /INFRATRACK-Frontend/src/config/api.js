// API base URL
const BASE_URL = 'http://127.0.0.1:5001';

// Configure axios defaults
import axios from 'axios';
axios.defaults.baseURL = BASE_URL;
axios.defaults.headers.common['Content-Type'] = 'application/json';
axios.defaults.headers.common['Accept'] = 'application/json';

// API URLs configuration
export const API_URLS = {
  BASE: BASE_URL,
  AUTH: `${BASE_URL}/api/auth`,
  CART: `${BASE_URL}/api/cart`,
  PRODUCTS: `${BASE_URL}/api/products`
};

// Auth endpoints
export const AUTH_ENDPOINTS = {
  HEALTH: `${BASE_URL}/api/health`,
  LOGIN: `${API_URLS.AUTH}/login`,
  SIGNUP: `${API_URLS.AUTH}/signup`
};

// Cart endpoints
export const CART_ENDPOINTS = {
  GET_CART: `${API_URLS.CART}`,
  ADD_TO_CART: `${API_URLS.CART}/add`,
  REMOVE_FROM_CART: `${API_URLS.CART}/remove`,
  UPDATE_QUANTITY: `${API_URLS.CART}/update`,
  CHECKOUT: `${API_URLS.CART}/checkout`,
  GET_COUNT: `${API_URLS.CART}/count`
};

// Product endpoints
export const PRODUCT_ENDPOINTS = {
  CEMENT: `${API_URLS.PRODUCTS}/cement`,
  STEEL: `${API_URLS.PRODUCTS}/steel`,
  WOOD: `${API_URLS.PRODUCTS}/wood`,
  PLUMBING: `${API_URLS.PRODUCTS}/plumbing`,
  SAND: `${API_URLS.PRODUCTS}/sand`
};

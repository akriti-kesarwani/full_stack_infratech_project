export const SERVER_PORT = 5001;

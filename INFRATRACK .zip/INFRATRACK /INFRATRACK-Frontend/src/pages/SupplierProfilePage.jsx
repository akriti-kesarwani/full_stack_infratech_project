import React from 'react';
import styled from 'styled-components';
import { FaPhone, FaEnvelope, FaStar } from 'react-icons/fa';

// Dummy Data for the Supplier
const supplier = {
  name: 'Anirudh Arora',
  logo: 'https://t3.ftcdn.net/jpg/04/60/91/88/360_F_460918802_XVCymFr7MoziFpnInbTDvrlblYhvAOi2.jpg', // Dummy logo image
  contactInfo: {
    phone: '+1234567890',
    email: 'supplier@gmail.com',
  },
  productCatalog: [
    { name: 'Cement', price: '1000rs.', availability: 'In Stock', image: 'https://5.imimg.com/data5/LR/OI/MY-39094180/cement.jpg' },
    { name: 'Steel Rods', price: '2000rs.', availability: 'Out of Stock', image: 'https://images.jdmagicbox.com/quickquotes/images_main/jsw-steel-tmt-iron-rod-10mm-2219579413-onzglb5u.jpg' },
    { name: 'Bricks', price: '150rs.', availability: 'In Stock', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsi9GlSJie__AjcFZY-cgiMUM5LsFQWGh57w&s' },
    { name: 'Pipes', price: '300rs.', availability: 'In Stock', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcVZ0UWiHdpbcPFYI8mBx9-ii6WcrWfzJVgwSvW-vKwSeNU3tLUCNZv74ZPcm3fFQztis&usqp=CAU' },
    { name: 'concrete', price: '2500rs.', availability: 'Out of Stock', image: 'https://australianslatecretesupplies.com.au/wp-content/uploads/2023/09/the-top-12-tools-you-will-need-when-working-with-concrete.jpg' },
    { name: 'Roofing Sheets', price: '5000rs.', availability: 'In Stock', image: 'https://connect.buildnext.in/wp-content/uploads/2020/04/metalroofingsheets-169-1024x576.jpg' },
    { name: 'Plumbing', price: '400rs.', availability: 'In Stock', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7L7LA5CuNwXwbDegvFy8rcAGz9OoC0ccH-Q&s' },
    { name: 'Electrical', price: '3500rs.', availability: 'In Stock', image: 'https://www.topcable.com/blog-electric-cable/wp-content/uploads/2016/07/When-is-it-necessary-to-perform-the-alternate-flexions-test-2.jpg' },
    { name: 'Windows & Doors', price: '600rs.', availability: 'In Stock', image: 'https://5.imimg.com/data5/SELLER/Default/2023/2/WI/GJ/AX/53635367/steel-doors-and-steel-windows.jpg' },
    { name: 'bricks', price: '80rs.', availability: 'Out of Stock', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsi9GlSJie__AjcFZY-cgiMUM5LsFQWGh57w&s' },
  ],
  reviews: [
    { name: 'John Doe', rating: 4, comment: 'Great service, fast delivery!' },
    { name: 'Jane Smith', rating: 5, comment: 'Amazing quality products. Highly recommended!' },
    { name: 'Bob Johnson', rating: 3, comment: 'Good, but a bit slow on delivery.' },
  ],
  location: '123 chowk , Prayagraj, UtterPradesh', // Optional for the map
};

const SupplierProfileContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const SupplierHeader = styled.div`
  display: flex;
  gap: 2rem;
  align-items: center;
`;

const SupplierLogo = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
`;

const SupplierInfo = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const SupplierName = styled.h1`
  font-size: 2rem;
  font-weight: 600;
`;

const SupplierContact = styled.div`
  display: flex;
  gap: 1rem;
`;

const ContactIcon = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ProductCatalog = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 1rem;
`;

const ProductCard = styled.div`
  background: #f9f9f9;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const ProductImage = styled.img`
  width: 100%;
  height: 150px;
  object-fit: cover;
  border-radius: 8px;
`;

const ProductName = styled.h3`
  font-size: 1.1rem;
  margin-top: 0.5rem;
`;

const ProductPrice = styled.p`
  font-weight: 600;
`;

const ProductAvailability = styled.p`
  color: ${(props) => (props.availability === 'In Stock' ? 'green' : 'red')};
`;

const ReviewsContainer = styled.div`
  margin-top: 2rem;
`;

const ReviewCard = styled.div`
  background: #f9f9f9;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const ReviewHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ReviewName = styled.p`
  font-weight: 600;
`;

const ReviewRating = styled.div`
  display: flex;
  gap: 0.2rem;
  color: #f39c12;
`;

const ContactForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 2rem;
`;

const InputField = styled.input`
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #ddd;
`;

const TextareaField = styled.textarea`
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #ddd;
`;

const ContactButton = styled.button`
  padding: 1rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background-color: #0056b3;
  }
`;

const SupplierProfilePage = () => {
  return (
    <SupplierProfileContainer>
      {/* Supplier Info */}
      <SupplierHeader>
        <SupplierLogo src={supplier.logo} alt="Supplier Logo" />
        <SupplierInfo>
          <SupplierName>{supplier.name}</SupplierName>
          <SupplierContact>
            <ContactIcon>
              <FaPhone />
              <span>{supplier.contactInfo.phone}</span>
            </ContactIcon>
            <ContactIcon>
              <FaEnvelope />
              <span>{supplier.contactInfo.email}</span>
            </ContactIcon>
          </SupplierContact>
        </SupplierInfo>
      </SupplierHeader>

      {/* Product Catalog */}
      <h2>Product Catalog</h2>
      <ProductCatalog>
        {supplier.productCatalog.map((product, index) => (
          <ProductCard key={index}>
            <ProductImage src={product.image} alt={product.name} />
            <ProductName>{product.name}</ProductName>
            <ProductPrice>{product.price}</ProductPrice>
            <ProductAvailability availability={product.availability}>
              {product.availability}
            </ProductAvailability>
          </ProductCard>
        ))}
      </ProductCatalog>

      {/* Reviews Section */}
      <ReviewsContainer>
        <h2>Customer Reviews</h2>
        {supplier.reviews.map((review, index) => (
          <ReviewCard key={index}>
            <ReviewHeader>
              <ReviewName>{review.name}</ReviewName>
              <ReviewRating>
                {[...Array(review.rating)].map((_, i) => (
                  <FaStar key={i} />
                ))}
              </ReviewRating>
            </ReviewHeader>
            <p>{review.comment}</p>
          </ReviewCard>
        ))}
      </ReviewsContainer>

      {/* Contact Form */}
      <ContactForm>
        <h2>Contact Supplier</h2>
        <InputField type="text" placeholder="Your Name" required />
        <InputField type="email" placeholder="Your Email" required />
        <TextareaField placeholder="Your Message" rows="5" required />
        <ContactButton type="submit">Send Message</ContactButton>
      </ContactForm>
    </SupplierProfileContainer>
  );
};

export default SupplierProfilePage;

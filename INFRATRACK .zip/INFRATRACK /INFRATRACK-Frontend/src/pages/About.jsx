import React, { useState } from 'react';

const About = () => {
  const [isExpanded, setIsExpanded] = useState(false);  // State to manage content visibility
  const [isMissionExpanded, setIsMissionExpanded] = useState(false);  // For Mission section
  const [isWhyExpanded, setIsWhyExpanded] = useState(false);  // For Why Choose Us section
  const [isValuesExpanded, setIsValuesExpanded] = useState(false);  // For Values section

  const toggleReadMore = (section) => {
    if (section === 'about') setIsExpanded(!isExpanded);
    if (section === 'mission') setIsMissionExpanded(!isMissionExpanded);
    if (section === 'why') setIsWhyExpanded(!isWhyExpanded);
    if (section === 'values') setIsValuesExpanded(!isValuesExpanded);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>About InfraMarket</h1>
      <div style={styles.content}>
        {/* Box for "Who We Are" */}
        <div style={styles.box}>
          <h2 style={styles.subHeading}>Who We Are</h2>
          <p style={styles.text}>
            InfraMarket is a leading provider of high-quality infrastructure materials and solutions for construction,
            renovation, and development projects. With years of experience in the industry, we serve contractors, builders,
            and individuals looking to access top-grade products that meet the needs of modern infrastructure.
          </p>
          <p style={styles.text}>
            From building materials like cement, steel, and sand, to electrical supplies, plumbing materials, and finishes,
            we offer a wide array of products to meet the demands of every project. Our aim is to ensure that infrastructure
            development is efficient, sustainable, and cost-effective by providing reliable materials to our customers.
          </p>
          <button onClick={() => toggleReadMore('about')} style={styles.readMoreButton}>
            {isExpanded ? 'Know Less' : 'Know More'}
          </button>
          {isExpanded && (
            <div style={styles.box}>
              <p style={styles.text}>
                InfraMarket’s expertise extends beyond simply providing materials. We also offer expert advice, timely deliveries, and customized solutions for any size project. Whether it's a small-scale residential renovation or a large-scale commercial development, we ensure that our clients have everything they need to succeed.
              </p>
            </div>
          )}
        </div>

        {/* Box for "Our Mission" */}
        <div style={styles.box}>
          <h2 style={styles.subHeading}>Our Mission</h2>
          <p style={styles.text}>
            Our mission is simple: To be the most trusted and reliable source of infrastructure materials in the market.
            We strive to offer premium quality products that meet rigorous standards, ensuring that construction and renovation
            projects are built on a strong foundation of excellence.
          </p>
          <p style={styles.text}>
            At InfraMarket, we are dedicated to supporting the growth of infrastructure across various industries by offering
            products that are not only durable but also eco-friendly and sustainable. Whether you’re working on a small residential
            project or a large commercial venture, we’re here to help you build the future.
          </p>
          <button onClick={() => toggleReadMore('mission')} style={styles.readMoreButton}>
            {isMissionExpanded ? 'Know Less' : 'Know More'}
          </button>
          {isMissionExpanded && (
            <div style={styles.box}>
              <p style={styles.text}>
                We also understand the need for continual innovation in the construction and infrastructure industry. Our team is always seeking new ways to enhance the quality, sustainability, and cost-effectiveness of the materials we provide.
              </p>
            </div>
          )}
        </div>

        {/* Box for "Why Choose Us" */}
        <div style={styles.box}>
          <h2 style={styles.subHeading}>Why Choose Us?</h2>
          <ul style={styles.list}>
            <li style={styles.listItem}>
              <strong>Wide Product Range:</strong> We offer a broad selection of products across multiple categories including
              Building Materials, Plumbing, Electrical, Finishes, Flooring, and Roofing.
            </li>
            <li style={styles.listItem}>
              <strong>Quality Assurance:</strong> All our products are sourced from trusted manufacturers, ensuring they meet
              the highest industry standards for quality and safety.
            </li>
            <li style={styles.listItem}>
              <strong>Competitive Pricing:</strong> We offer some of the most competitive pricing in the market, without compromising
              on product quality. We strive to make quality materials affordable for all.
            </li>
            <li style={styles.listItem}>
              <strong>Fast and Reliable Delivery:</strong> We understand the importance of time in construction, which is why we
              ensure prompt and reliable delivery for all orders, anywhere in the country.
            </li>
            <li style={styles.listItem}>
              <strong>Customer-Centric Approach:</strong> Our customers are at the heart of everything we do. We offer personalized
              support and expert advice to guide you through your product choices and ensure you’re satisfied with your purchase.
            </li>
          </ul>
          <button onClick={() => toggleReadMore('why')} style={styles.readMoreButton}>
            {isWhyExpanded ? 'Know Less' : 'Know More'}
          </button>
          {isWhyExpanded && (
            <div style={styles.box}>
              <p style={styles.text}>
                Our customer-first approach means we not only deliver high-quality products, but also offer ongoing support for projects, ensuring they stay on track and within budget. From project inception to completion, we’re with you every step of the way.
              </p>
            </div>
          )}
        </div>

        {/* Box for "Our Values" */}
        <div style={styles.box}>
          <h2 style={styles.subHeading}>Our Values</h2>
          <p style={styles.text}>
            <strong>Integrity:</strong> We believe in doing the right thing, always. Transparency and honesty guide our business
            practices and interactions.
          </p>
          <p style={styles.text}>
            <strong>Excellence:</strong> We are committed to providing the highest quality products and services in the industry.
          </p>
          <p style={styles.text}>
            <strong>Sustainability:</strong> We prioritize eco-friendly and sustainable practices in sourcing and delivering products
            that help build a greener future.
          </p>
          <button onClick={() => toggleReadMore('values')} style={styles.readMoreButton}>
            {isValuesExpanded ? 'Know Less' : 'Know More'}
          </button>
          {isValuesExpanded && (
            <div style={styles.box}>
              <p style={styles.text}>
                We place a high emphasis on creating a lasting impact in our industry. Our values of integrity, excellence, and sustainability are the foundation of everything we do, and we’re committed to making the world a better place through our work.
              </p>
            </div>
          )}
        </div>

        {/* Box for Product Categories */}
        <div style={styles.box}>
          <h2 style={styles.subHeading}>Our Product Categories</h2>
          <p style={styles.text}>
            At InfraMarket, we pride ourselves on offering a diverse range of high-quality products to meet the needs of every construction and renovation project. Whether you're building a new home, renovating an office, or working on a commercial development, we have the materials you need to ensure the job is done right. Our product categories are designed to cover all aspects of infrastructure development, from the foundation to the finishing touches.
          </p>
          <ul style={styles.list}>
            <li style={styles.listItem}>
              <strong>Building Materials:</strong> We provide essential building materials like cement, steel, bricks, and aggregates that ensure the structural integrity and foundation of any project.
            </li>
            <li style={styles.listItem}>
              <strong>Plumbing:</strong> Our plumbing products include pipes, faucets, fittings, and fixtures, sourced from the best manufacturers for reliability and long-term performance.
            </li>
            <li style={styles.listItem}>
              <strong>Electrical:</strong> We offer electrical supplies including wiring, circuit breakers, light fixtures, and outlets that meet high safety standards and guarantee optimal performance.
            </li>
            <li style={styles.listItem}>
              <strong>Finishes:</strong> From paint and drywall to tiling and finishing products, we provide a wide selection of materials that give your projects the perfect final touch.
            </li>
            <li style={styles.listItem}>
              <strong>Flooring:</strong> Choose from a variety of flooring materials including tiles, hardwood, vinyl, and carpets for durable and aesthetically pleasing results.
            </li>
            <li style={styles.listItem}>
              <strong>Windows & Doors:</strong> Our range of windows and doors ensures energy efficiency, security, and stylish designs for both residential and commercial applications.
            </li>
            <li style={styles.listItem}>
              <strong>Roofing:</strong> We supply roofing materials such as shingles, tiles, membranes, and other components to protect and enhance the structural integrity of your buildings.
            </li>
          </ul>
        </div>

        {/* Added image after "Our Product Categories" */}
        <div style={styles.imageContainer}>
          <img
          
            src="https://www.clipartmax.com/png/middle/83-837060_flag-of-india-map-clip-art-india-states-and-capitals-list-2016.png" // Dummy image link
            alt="Product Categories"
            style={styles.image}
          />
        </div>

      </div>
    </div>
  );
};

const styles = {
  container: {
    width: '80%',
    margin: '0 auto',
    padding: '40px',
    backgroundColor: '#f9f9f9',
    fontFamily: 'Arial, sans-serif',
    borderRadius: '8px',
  },
  heading: {
    textAlign: 'center',
    color: '#2c3e50',
    fontSize: '36px',
    marginBottom: '30px',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  subHeading: {
    color: '#34495e',
    fontSize: '24px',
    marginBottom: '15px',
    fontWeight: '600',
  },
  content: {
    marginBottom: '30px',
  },
  text: {
    color: '#555',
    marginBottom: '15px',
    fontSize: '18px',
    lineHeight: '1.6',
  },
  box: {
    backgroundColor: '#fff',
    padding: '20px',
    marginBottom: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease',
  },
  readMoreButton: {
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    marginTop: '20px',
    fontSize: '16px',
    display: 'block',
    width: '200px',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  imageContainer: {
    marginTop: '30px',
    textAlign: 'center',
  },
  image: {
    maxWidth: '100%',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
};

export default About;

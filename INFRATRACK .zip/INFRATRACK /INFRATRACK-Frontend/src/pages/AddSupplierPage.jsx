import React, { useState } from 'react';
import styled from 'styled-components';

const Container = styled.div`
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

const Title = styled.h2`
  text-align: center;
  color: ${(props) => props.theme.primary};
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 500px;
  margin: 0 auto;

  input, select, textarea {
    padding: 0.8rem;
    border: 1px solid ${(props) => props.theme.borderColor};
    border-radius: 8px;
    font-size: 1rem;
  }

  button {
    padding: 0.8rem;
    border: none;
    background-color: ${(props) => props.theme.primary};
    color: white;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;

    &:hover {
      background-color: ${(props) => props.theme.primaryDark};
    }
  }
`;

const SupplierList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const SupplierCard = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border: 1px solid ${(props) => props.theme.borderColor};
  border-radius: 8px;
`;

const SupplierImage = styled.img`
  width: 50px;
  height: 50px;
  border-radius: 50%;
`;

const DummyImage = 'https://via.placeholder.com/150'; // Dummy image URL for testing

const suppliersData = [
  { id: 1, name: 'Supplier One', contact: 'contact1@domain.com', productCategory: 'Tiles', image: DummyImage },
  { id: 2, name: 'Supplier Two', contact: 'contact2@domain.com', productCategory: 'Wood', image: DummyImage },
  { id: 3, name: 'Supplier Three', contact: 'contact3@domain.com', productCategory: 'Steel', image: DummyImage },
  { id: 4, name: 'Supplier Four', contact: 'contact4@domain.com', productCategory: 'Plumbing', image: DummyImage },
  { id: 5, name: 'Supplier Five', contact: 'contact5@domain.com', productCategory: 'Cement', image: DummyImage },
  { id: 6, name: 'Supplier Six', contact: 'contact6@domain.com', productCategory: 'Tile', image: DummyImage },
  { id: 7, name: 'Supplier Seven', contact: 'contact7@domain.com', productCategory: 'Wood', image: DummyImage },
  { id: 8, name: 'Supplier Eight', contact: 'contact8@domain.com', productCategory: 'Steel', image: DummyImage },
  { id: 9, name: 'Supplier Nine', contact: 'contact9@domain.com', productCategory: 'Plumbing', image: DummyImage },
  { id: 10, name: 'Supplier Ten', contact: 'contact10@domain.com', productCategory: 'Cement', image: DummyImage },
];

const AddSupplierPage = () => {
  const [suppliers, setSuppliers] = useState(suppliersData);
  const [newSupplier, setNewSupplier] = useState({
    name: '',
    contact: '',
    productCategory: '',
    image: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewSupplier({
      ...newSupplier,
      [name]: value,
    });
  };

  const handleAddSupplier = (e) => {
    e.preventDefault();
    if (newSupplier.name && newSupplier.contact && newSupplier.productCategory && newSupplier.image) {
      const newId = suppliers.length + 1;
      setSuppliers([
        ...suppliers,
        { ...newSupplier, id: newId },
      ]);
      setNewSupplier({ name: '', contact: '', productCategory: '', image: '' });
    } else {
      alert("Please fill all fields");
    }
  };

  const handleDeleteSupplier = (id) => {
    const updatedSuppliers = suppliers.filter(supplier => supplier.id !== id);
    setSuppliers(updatedSuppliers);
  };

  const handleEditSupplier = (id) => {
    const supplierToEdit = suppliers.find(supplier => supplier.id === id);
    setNewSupplier(supplierToEdit);
  };

  return (
    <Container>
      <Title>Add / Manage Suppliers</Title>

      {/* Add Supplier Form */}
      <Form onSubmit={handleAddSupplier}>
        <input
          type="text"
          name="name"
          value={newSupplier.name}
          onChange={handleInputChange}
          placeholder="Supplier Name"
        />
        <input
          type="email"
          name="contact"
          value={newSupplier.contact}
          onChange={handleInputChange}
          placeholder="Contact Email"
        />
        <select
          name="productCategory"
          value={newSupplier.productCategory}
          onChange={handleInputChange}
        >
          <option value="">Select Product Category</option>
          <option value="Tiles">Tiles</option>
          <option value="Wood">Wood</option>
          <option value="Steel">Steel</option>
          <option value="Plumbing">Plumbing</option>
          <option value="Cement">Cement</option>
        </select>
        <input
          type="text"
          name="image"
          value={newSupplier.image}
          onChange={handleInputChange}
          placeholder="Supplier Image URL"
        />
        <button type="submit">Add Supplier</button>
      </Form>

      {/* List of Suppliers */}
      <SupplierList>
        {suppliers.map((supplier) => (
          <SupplierCard key={supplier.id}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <SupplierImage src={supplier.image} alt="Supplier" />
              <div>
                <h4>{supplier.name}</h4>
                <p>{supplier.contact}</p>
                <p>{supplier.productCategory}</p>
              </div>
            </div>
            <div>
              <button onClick={() => handleEditSupplier(supplier.id)}>Edit</button>
              <button onClick={() => handleDeleteSupplier(supplier.id)}>Delete</button>
            </div>
          </SupplierCard>
        ))}
      </SupplierList>
    </Container>
  );
};

export default AddSupplierPage;

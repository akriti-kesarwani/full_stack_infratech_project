import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { sendCartNotification } from '../services/notificationService';
import { CART_ENDPOINTS } from '../config/api';
import '../styles/CartPage.css';

const CartPage = () => {
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState('');
  const [bankDetails, setBankDetails] = useState({ accountNumber: '', ifsc: '' });
  const [cardDetails, setCardDetails] = useState({ cardNumber: '', expiryDate: '', cvv: '' });
  const [upiDetails, setUpiDetails] = useState('');
  const [shippingAddress, setShippingAddress] = useState({
    street: '',
    city: '',
    state: '',
    pincode: '',
    phone: ''
  });
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const navigate = useNavigate();

  // Load cart items on component mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }
    fetchCart();
  }, [navigate]);

  const fetchCart = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(CART_ENDPOINTS.GET_CART, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.data.success) {
        console.log('Cart items loaded:', response.data.cart);
        setCart(response.data.cart);
        setTotal(response.data.total);
      } else {
        throw new Error(response.data.message || 'Failed to fetch cart');
      }
    } catch (error) {
      console.error('Error fetching cart:', error);
      if (error.response?.status === 401) {
        alert('Your session has expired. Please log in again.');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
      } else if (!navigator.onLine) {
        alert('You appear to be offline. Please check your internet connection.');
      } else {
        alert('Failed to load cart items. Please try again.');
      }
    }
  };

  // Handle quantity changes
  const updateQuantity = async (productId, newQuantity) => {
    try {
      if (newQuantity < 1) return;

      const response = await axios.put(CART_ENDPOINTS.UPDATE_QUANTITY, {
        productId,
        quantity: newQuantity
      });

      if (response.data.success) {
        fetchCart(); // Refresh cart after update
      } else {
        throw new Error(response.data.message || 'Failed to update quantity');
      }
    } catch (error) {
      console.error('Error updating quantity:', error);
      alert('Failed to update quantity. Please try again.');
    }
  };

  // Handle removing items
  const removeItem = async (productId) => {
    try {
      console.log('Cart state before remove:', cart); // Debug log
      console.log('Removing item with ID:', productId); // Debug log
      
      const item = cart.find(item => item.productId === productId);
      if (!item) {
        console.error('Item not found in cart:', productId);
        return;
      }
      console.log('Item to remove:', item); // Debug log
      
      // Add headers
      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      };
      
      const response = await axios.delete(`${CART_ENDPOINTS.REMOVE_FROM_CART}/${encodeURIComponent(productId)}`, config);
      
      if (response.data.success) {
        console.log('Remove successful:', response.data);
        setCart(prevCart => {
          const updated = prevCart.filter(item => item.productId !== productId);
          console.log('Updated cart state:', updated); // Debug log
          return updated;
        });
        setTotal(response.data.total);
      } else {
        throw new Error(response.data.message || 'Failed to remove item');
      }
    } catch (error) {
      console.error('Error removing item:', error);
      alert(error.response?.data?.message || 'Failed to remove item. Please try again.');
    }
  };

  // Handle checkout
  const handleCheckout = async () => {
    try {
      // Validate required fields
      if (!paymentMethod) {
        alert('Please select a payment method');
        return;
      }
      if (!deliveryMethod) {
        alert('Please select a delivery method');
        return;
      }
      if (!shippingAddress.street || !shippingAddress.city || !shippingAddress.state || !shippingAddress.pincode || !shippingAddress.phone) {
        alert('Please fill in all shipping address fields');
        return;
      }

      // Validate payment details based on selected method
      if (paymentMethod === 'bank' && (!bankDetails.accountNumber || !bankDetails.ifsc)) {
        alert('Please fill in all bank details');
        return;
      }
      if (paymentMethod === 'card' && (!cardDetails.cardNumber || !cardDetails.expiryDate || !cardDetails.cvv)) {
        alert('Please fill in all card details');
        return;
      }
      if (paymentMethod === 'upi' && !upiDetails) {
        alert('Please enter UPI ID');
        return;
      }

      const token = localStorage.getItem('token');
      const checkoutData = {
        items: cart,
        total,
        paymentMethod,
        deliveryMethod,
        shippingAddress,
        paymentDetails: paymentMethod === 'bank' ? bankDetails : 
                       paymentMethod === 'card' ? cardDetails : 
                       paymentMethod === 'upi' ? { upiId: upiDetails } : null
      };

      const response = await axios.post(CART_ENDPOINTS.CHECKOUT, checkoutData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.data.success) {
        setPaymentSuccess(true);
        // Clear cart after successful checkout
        setCart([]);
        setTotal(0);
        // Send notification
        await sendCartNotification('Order placed successfully!');
        // Redirect to home page
        navigate('/');
      } else {
        throw new Error(response.data.message || 'Checkout failed');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      if (error.response?.status === 401) {
        alert('Your session has expired. Please log in again.');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
      } else {
        alert(error.response?.data?.message || 'Failed to process checkout. Please try again.');
      }
    }
  };

  const renderPaymentFields = () => {
    switch (paymentMethod) {
      case 'bank':
        return (
          <div className="payment-fields">
            <input
              type="text"
              placeholder="Account Number"
              value={bankDetails.accountNumber}
              onChange={(e) => setBankDetails({...bankDetails, accountNumber: e.target.value})}
            />
            <input
              type="text"
              placeholder="IFSC Code"
              value={bankDetails.ifsc}
              onChange={(e) => setBankDetails({...bankDetails, ifsc: e.target.value})}
            />
          </div>
        );
      case 'card':
        return (
          <div className="payment-fields">
            <input
              type="text"
              placeholder="Card Number"
              value={cardDetails.cardNumber}
              onChange={(e) => setCardDetails({...cardDetails, cardNumber: e.target.value})}
            />
            <input
              type="text"
              placeholder="MM/YY"
              value={cardDetails.expiryDate}
              onChange={(e) => setCardDetails({...cardDetails, expiryDate: e.target.value})}
            />
            <input
              type="password"
              placeholder="CVV"
              value={cardDetails.cvv}
              onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
            />
          </div>
        );
      case 'upi':
        return (
          <div className="payment-fields">
            <input
              type="text"
              placeholder="UPI ID"
              value={upiDetails}
              onChange={(e) => setUpiDetails(e.target.value)}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="cart-page">
      <h1>Shopping Cart</h1>
      
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <>
          <div className="cart-items">
            {cart.map((item) => (
              <div key={item.productId} className="cart-item">
                <img src={item.image} alt={item.productName} className="item-image" />
                <div className="item-details">
                  <h3>{item.productName}</h3>
                  <p>Brand: {item.brand}</p>
                  <p>Price: ₹{item.price}</p>
                  <div className="quantity-controls">
                    <button onClick={() => updateQuantity(item.productId, item.quantity - 1)}>-</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.productId, item.quantity + 1)}>+</button>
                  </div>
                  <button onClick={() => removeItem(item.productId)} className="remove-btn">
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="checkout-section">
            <h2>Total: ₹{total}</h2>
            
            <div className="shipping-section">
              <h3>Shipping Address</h3>
              <div className="address-details">
                <input
                  type="text"
                  placeholder="Street Address"
                  value={shippingAddress.street}
                  onChange={(e) => setShippingAddress({...shippingAddress, street: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="City"
                  value={shippingAddress.city}
                  onChange={(e) => setShippingAddress({...shippingAddress, city: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="State"
                  value={shippingAddress.state}
                  onChange={(e) => setShippingAddress({...shippingAddress, state: e.target.value})}
                />
                <input
                  type="text"
                  placeholder="PIN Code"
                  value={shippingAddress.pincode}
                  onChange={(e) => setShippingAddress({...shippingAddress, pincode: e.target.value})}
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={shippingAddress.phone}
                  onChange={(e) => setShippingAddress({...shippingAddress, phone: e.target.value})}
                />
              </div>
            </div>

            <div className="payment-section">
              <h3>Select Payment Method</h3>
              <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                <option value="">Select...</option>
                <option value="bank">Bank Transfer</option>
                <option value="card">Credit/Debit Card</option>
                <option value="upi">UPI</option>
              </select>

              {renderPaymentFields()}
            </div>

            <div className="delivery-section">
              <h3>Select Delivery Method</h3>
              <select value={deliveryMethod} onChange={(e) => setDeliveryMethod(e.target.value)}>
                <option value="">Select...</option>
                <option value="Standard">Standard Delivery (3-5 days)</option>
                <option value="Express">Express Delivery (1-2 days)</option>
                <option value="Pickup">Store Pickup</option>
              </select>
            </div>

            <button onClick={handleCheckout} className="checkout-btn">
              Proceed to Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CartPage;

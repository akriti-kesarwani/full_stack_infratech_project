import React, { useState } from 'react';
import styled from 'styled-components';

const Container = styled.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const Header = styled.h1`
  font-size: 2rem;
  color: ${(props) => props.theme.primary};
  text-align: center;
  margin-bottom: 1rem;
`;

const SearchBar = styled.input`
  width: 100%;
  padding: 0.75rem;
  margin-bottom: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${(props) => props.theme.primary};
  }
`;

const FiltersContainer = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
`;

const Filter = styled.select`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${(props) => props.theme.primary};
  }
`;

const SupplierListContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
`;

const SupplierCard = styled.div`
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;

  &:hover {
    transform: translateY(-5px);
  }
`;

const SupplierImage = styled.img`
  width: 100%;
  height: 180px;
  object-fit: cover;
`;

const SupplierDetails = styled.div`
  padding: 1rem;
`;

const SupplierName = styled.h3`
  font-size: 1.25rem;
  margin: 0;
  color: ${(props) => props.theme.primary};
`;

const SupplierLocation = styled.p`
  margin: 0.5rem 0;
  font-size: 0.9rem;
  color: #666;
`;

const SupplierDescription = styled.p`
  font-size: 0.85rem;
  color: #555;
  line-height: 1.4;
`;

const ContactButton = styled.a`
  display: inline-block;
  margin-top: 1rem;
  padding: 0.5rem 1rem;
  background: ${(props) => props.theme.primary};
  color: white;
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 600;
  border-radius: 8px;
  transition: all 0.3s ease;

  &:hover {
    background: ${(props) => props.theme.primaryDark};
    transform: translateY(-2px);
  }
`;

const SupplierList = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const suppliers = [
    {
      name: ' Tiles',
      location: 'New York',
      category: 'Tiles',
      description: 'High-quality tiles for all your construction needs.',
      image: 'https://images.orientbell.com/media/catalog/product/c/r/craftclad_mosaic_4x8_grey_1.jpg',
      contactLink: '/suppliers/contact/tiles',
    },
    {
      name: 'SteelPro Supplies',
      location: 'Los Angeles',
      category: 'Steel',
      description: 'Top-grade steel suppliers for industrial projects.',
      image: 'https://dhandsteels.com/wp-content/uploads/2020/12/alloy-steel-bars-1200x820.jpg',
      contactLink: '/suppliers/contact/steelpro-supplies',
    },
    {
      name: 'WoodWorks',
      location: 'Chicago',
      category: 'Wood',
      description: 'Premium wood materials for construction and furniture.',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8mcl8B4okNV5R4TFxYXeED1EXAuFsXyplc4KHKtfeuDAt5E507TA2NNm6hvMqLLOpfCM&usqp=CAU',
      contactLink: '/suppliers/contact/woodworks',
    },
    {
      name: 'Plumbing Hub',
      location: 'Houston',
      category: 'Plumbing',
      description: 'Affordable plumbing supplies for all types of projects.',
      image: 'https://m.media-amazon.com/images/I/71eq+ki5D6S.jpg',
      contactLink: '/suppliers/contact/plumbing-hub',
    },
    {
      name: 'CementWorks',
      location: 'Phoenix',
      category: 'Cement',
      description: 'Reliable cement for durable construction.',
      image: 'https://4.imimg.com/data4/GU/BG/MY-3194261/orient-ppc-cement.jpg',
      contactLink: '/suppliers/contact/cementworks',
    },
    {
      name: 'Sand & Stone Co.',
      location: 'Philadelphia',
      category: 'Sand',
      description: 'High-grade sand for construction and landscaping.',
      image: 'https://m.media-amazon.com/images/I/81uEPaU309L.jpg',
      contactLink: '/suppliers/contact/sand-stone-co',
    },
    {
      name: 'MegaMix Cement',
      location: 'San Antonio',
      category: 'Cement',
      description: 'Custom cement mixes for diverse projects.',
      image: 'https://m.media-amazon.com/images/I/81uEPaU309L.jpg',
      contactLink: '/suppliers/contact/megamix-cement',
    },
    {
      name: 'SteelMart',
      location: 'San Diego',
      category: 'Steel',
      description: 'Affordable steel products for all industries.',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7mYBs2iSV9LG6zL-6S16TuNZWODp1SWQfcw&s',
      contactLink: '/suppliers/contact/steelmart',
    },
    {
      name: 'Tile Kingdom',
      location: 'Dallas',
      category: 'Tiles',
      description: 'Decorative and functional tiles for any project.',
      image: 'https://tileswale.com/uploads/products/164078470388_9195_580658.jpg',
      contactLink: '/suppliers/contact/tile-kingdom',
    },
    {
      name: 'Woodland Supplies',
      location: 'San Jose',
      category: 'Wood',
      description: 'Eco-friendly wood supplies for sustainable projects.',
      image: 'https://picketandrail.com/cdn/shop/articles/dangers-of-pine-wood-415894.jpg?v=1686388565',
      contactLink: '/suppliers/contact/woodland-supplies',
    },
  ];

  const filteredSuppliers = suppliers.filter((supplier) => {
    const matchesSearch = supplier.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesLocation = !selectedLocation || supplier.location === selectedLocation;
    const matchesCategory = !selectedCategory || supplier.category === selectedCategory;

    return matchesSearch && matchesLocation && matchesCategory;
  });

  return (
    <Container>
      <Header>Suppliers List</Header>
      <SearchBar
        type="text"
        placeholder="Search suppliers by name, location, or category..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <FiltersContainer>
        <Filter
          value={selectedLocation}
          onChange={(e) => setSelectedLocation(e.target.value)}
        >
          <option value="">All Locations</option>
          <option value="New York">New York</option>
          <option value="Los Angeles">Los Angeles</option>
          <option value="Chicago">Chicago</option>
          <option value="Houston">Houston</option>
          <option value="Phoenix">Phoenix</option>
        </Filter>
        <Filter
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          <option value="Tiles">Tiles</option>
          <option value="Steel">Steel</option>
          <option value="Wood">Wood</option>
          <option value="Plumbing">Plumbing</option>
          <option value="Cement">Cement</option>
          <option value="Sand">Sand</option>
        </Filter>
      </FiltersContainer>
      <SupplierListContainer>
        {filteredSuppliers.map((supplier, index) => (
          <SupplierCard key={index}>
            <SupplierImage src={supplier.image} alt={supplier.name} />
            <SupplierDetails>
              <SupplierName>{supplier.name}</SupplierName>
              <SupplierLocation>{supplier.location}</SupplierLocation>
              <SupplierDescription>{supplier.description}</SupplierDescription>
              <ContactButton href={supplier.contactLink}>Contact</ContactButton>
            </SupplierDetails>
          </SupplierCard>
        ))}
      </SupplierListContainer>
    </Container>
  );
};

export default SupplierList;

import React from 'react';

const Franchise = () => {
  const franchiseImages = [
    { id: 1, name: 'Mumbai', image: 'https://i.ytimg.com/vi/73ag7pBlZec/sddefault.jpg' },
    { id: 2, name: 'Prayagraj', image: 'https://i.ytimg.com/vi/kDlavpEkbb8/maxresdefault.jpg' },
    { id: 3, name: 'Ahembdabad', image: 'https://i.ytimg.com/vi/vcXQ43k-JBg/sddefault.jpg' },
    { id: 4, name: 'Punjab', image: 'https://static.vecteezy.com/system/resources/previews/007/365/319/non_2x/punjab-handwritten-stock-lettering-typography-states-of-india-calligraphy-for-logotype-badge-icon-card-postcard-logo-banner-tag-illustration-eps10-mandala-orange-multicolor-bright-gradient-vector.jpg' },
    { id: 5, name: 'Delhi', image: 'https://i.ytimg.com/vi/UGaEmjiWfkA/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLA6ZnSZJYL0gDUB_GqsvqwtXUFNTg' },
  ];

  const styles = {
    container: {
      fontFamily: 'Arial, sans-serif',
      padding: '20px',
    },
    videoContainer: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: '30px',
    },
    video: {
      width: '100%',
      maxWidth: '800px',
      height: '450px',
    },
    heading: {
      fontSize: '24px',
      fontWeight: 'bold',
      textAlign: 'center',
      margin: '20px 0',
      color: '#FF5733',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      padding: '20px 0',
    },
    card: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    },
    image: {
      width: '100%',
      height: '200px',
      objectFit: 'cover',
      borderRadius: '8px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    locationName: {
      marginTop: '10px',
      fontWeight: 'bold',
      fontSize: '16px',
    },
  };

  return (
    <div style={styles.container}>
      {/* Video Section */}
      <div style={styles.videoContainer}>
        <iframe
          style={styles.video}
          src="https://www.youtube.com/embed/LVUdxTb-Bx4"
          title="Franchise Video"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </div>

      {/* Heading */}
      <h1 style={styles.heading}>Exclusive Showrooms</h1>

      {/* Franchise Image Grid */}
      <div style={styles.grid}>
        {franchiseImages.map((franchise) => (
          <div key={franchise.id} style={styles.card}>
            <img src={franchise.image} alt={franchise.name} style={styles.image} />
            <p style={styles.locationName}>{franchise.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Franchise;

import React from 'react';

const Suppliers = () => {
  // Sample supplier data with expertise and images
  const suppliers = [
    { 
      id: 1, 
      name: 'Supplier A', 
      contact: '123-456-7890', 
      email: 'supplierA@example.com', 
      address: '123 Main St, City, Country',
      expertise: 'The electronics industry involves the design, development, and manufacturing of electronic devices and components, including consumer gadgets, industrial equipment, and communication systems. Suppliers in this sector provide essential components such as semiconductors, circuit boards, and communication devices used in various industries.', 
      image: 'https://thumbs.dreamstime.com/z/female-electronic-engineer-testing-computer-motherboard-labor-young-attractive-digital-pc-laboratory-99383384.jpg'
    },
    { 
      id: 2, 
      name: 'Supplier B', 
      contact: '234-567-8901', 
      email: 'supplierB@example.com', 
      address: '456 Elm St, City, Country',
      expertise: 'The furniture industry focuses on the design, production, and sale of functional and aesthetic furniture pieces for homes, offices, and other spaces. Suppliers in this sector offer products ranging from seating and tables to storage solutions, using various materials like wood, metal, and upholstery.', 
      image: 'https://www.shutterstock.com/image-photo/concentrated-millennial-girl-sit-on-260nw-2473271475.jpg'
    },
    { 
      id: 3, 
      name: 'Supplier C', 
      contact: '345-678-9012', 
      email: 'supplierC@example.com', 
      address: '789 Pine St, City, Country',
      expertise: 'The plumbing industry involves the installation, maintenance, and repair of systems that carry water, gas, and waste in residential, commercial, and industrial buildings. Suppliers in this sector provide pipes, fixtures, valves, pumps, and other essential plumbing components for construction and renovation projects.',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 4, 
      name: 'Supplier D', 
      contact: '456-789-0123', 
      email: 'supplierD@example.com', 
      address: '101 Oak St, City, Country',
      expertise: 'Automotive',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 5, 
      name: 'Supplier E', 
      contact: '567-890-1234', 
      email: 'supplierE@example.com', 
      address: '202 Maple St, City, Country',
      expertise: 'The plumbing industry involves the installation, maintenance, and repair of systems that carry water, gas, and waste in residential, commercial, and industrial buildings. Suppliers in this sector provide pipes, fixtures, valves, pumps, and other essential plumbing components for construction and renovation projects.',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 6, 
      name: 'Supplier F', 
      contact: '678-901-2345', 
      email: 'supplierF@example.com', 
      address: '303 Birch St, City, Country',
      expertise: 'Food & Beverages',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 7, 
      name: 'Supplier G', 
      contact: '789-012-3456', 
      email: 'supplierG@example.com', 
      address: '404 Cedar St, City, Country',
      expertise: 'Windows & Doors',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 8, 
      name: 'Supplier H', 
      contact: '890-123-4567', 
      email: 'supplierH@example.com', 
      address: '505 Pine St, City, Country',
      expertise: 'Windows & Doors',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 9, 
      name: 'Supplier I', 
      contact: '901-234-5678', 
      email: 'supplierI@example.com', 
      address: '606 Oak St, City, Country',
      expertise: 'Windows & Doors',
      image: 'https://via.placeholder.com/150'
    },
    { 
      id: 10, 
      name: 'Supplier J', 
      contact: '012-345-6789', 
      email: 'supplierJ@example.com', 
      address: '707 Maple St, City, Country',
      expertise: 'Technology',
      image: 'https://via.placeholder.com/150'
    }
  ];

  // Inline CSS Styles
  const styles = {
    suppliersContainer: {
      fontFamily: 'Windows & Doors',
      padding: '20px',
    },
    ul: {
      listStyleType: 'none',
      padding: '0',
    },
    supplierCard: {
      display: 'flex',
      border: '1px solid #ccc',
      margin: '10px 0',
      padding: '15px',
      borderRadius: '8px',
      backgroundColor: '#f9f9f9',
      alignItems: 'center',
    },
    supplierImage: {
      width: '150px',
      height: '150px',
      objectFit: 'cover',
      borderRadius: '8px',
      marginRight: '20px',
    },
    supplierInfo: {
      flexGrow: 1,
    },
    supplierInfoTitle: {
      margin: '0',
    },
    supplierInfoText: {
      margin: '5px 0',
    },
    supplierInfoStrong: {
      fontWeight: 'bold',
    },
    connectButton: {
      padding: '10px 15px',
      backgroundColor: '#007BFF',
      color: 'white',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      fontSize: '16px',
      transition: 'background-color 0.3s',
    },
    connectButtonHover: {
      backgroundColor: '#0056b3',
    }
  };

  const handleConnectClick = (name) => {
    alert(`Connecting with ${name}!`);
  };

  return (
    <div style={styles.suppliersContainer}>
      <h1>Suppliers List</h1>
      <ul style={styles.ul}>
        {suppliers.map(supplier => (
          <li key={supplier.id} style={styles.supplierCard}>
            <img src={supplier.image} alt={supplier.name} style={styles.supplierImage} />
            <div style={styles.supplierInfo}>
              <h2 style={styles.supplierInfoTitle}>{supplier.name}</h2>
              <p style={styles.supplierInfoText}><strong style={styles.supplierInfoStrong}>Contact:</strong> {supplier.contact}</p>
              <p style={styles.supplierInfoText}><strong style={styles.supplierInfoStrong}>Email:</strong> {supplier.email}</p>
              <p style={styles.supplierInfoText}><strong style={styles.supplierInfoStrong}>Address:</strong> {supplier.address}</p>
              <p style={styles.supplierInfoText}><strong style={styles.supplierInfoStrong}>Expertise:</strong> {supplier.expertise}</p>
              <button 
                style={styles.connectButton} 
                onClick={() => handleConnectClick(supplier.name)}
              >
                Connect
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Suppliers;

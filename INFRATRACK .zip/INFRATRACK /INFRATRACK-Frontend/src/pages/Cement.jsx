import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { API_URLS } from '../config/api';
import cement1 from './images/cement/cement1.avif';
import cement2 from './images/cement/cement2.webp';
import cement3 from './images/cement/cement3.jpg';
import cement4 from './images/cement/cement4.jpg';
import cement5 from './images/cement/cement5.jpeg';
import cement6 from './images/cement/cement6.jpg';

const Cement = () => {
  const [cartCount, setCartCount] = useState(0);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  const cementProducts = [
    { id: 'cement1', name: 'Portland Cement', brand: 'UltraTech', price: '350 Rs', image: cement1 },
    { id: 'cement2', name: 'PPC Cement', brand: 'ACC', price: '320 Rs', image: cement2 },
    { id: 'cement3', name: 'White Cement', brand: 'JK Cement', price: '400 Rs', image: cement3 },
    { id: 'cement4', name: 'Quick Setting Cement', brand: 'Ambuja', price: '380 Rs', image: cement4 },
    { id: 'cement5', name: 'Masonry Cement', brand: 'Birla', price: '340 Rs', image: cement5 },
    { id: 'cement6', name: 'Waterproof Cement', brand: 'Dalmia', price: '420 Rs', image: cement6 }
  ];

  const styles = {
    container: {
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      margin: '20px 0',
    },
    card: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '15px',
      textAlign: 'center',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    image: {
      width: '150px',
      height: '150px',
      borderRadius: '8px',
      marginBottom: '10px',
      objectFit: 'cover',
    },
    productName: {
      fontSize: '18px',
      fontWeight: 'bold',
      marginBottom: '10px',
    },
    productBrand: {
      fontSize: '16px',
      color: '#555',
      marginBottom: '10px',
    },
    productPrice: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#007BFF',
      marginBottom: '10px',
    },
    button: {
      padding: '10px 15px',
      backgroundColor: '#007BFF',
      color: 'white',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
  };

  useEffect(() => {
    // Check authentication status
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (token && user) {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    const fetchCartCount = async () => {
      if (!isAuthenticated) return;
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`${API_URLS.CART}/count`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        if (response.data.success) {
          setCartCount(response.data.count);
        }
      } catch (error) {
        console.error('Error fetching cart count:', error);
        if (error.response?.status === 401) {
          // Token expired or invalid
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          localStorage.removeItem('userId');
          setIsAuthenticated(false);
        }
      }
    };
    fetchCartCount();
  }, [isAuthenticated]);

  const handleAddToCart = async (product) => {
    if (!isAuthenticated) {
      alert('Please log in to add items to cart');
      navigate('/login');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`${API_URLS.CART}/add`, {
        productId: product.id
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCartCount(prevCount => prevCount + 1);
        alert('Product added to cart successfully!');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      if (error.response?.status === 401) {
        alert('Your session has expired. Please log in again.');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('userId');
        setIsAuthenticated(false);
        navigate('/login');
      } else {
        alert('Failed to add product to cart. Please try again.');
      }
    }
  };

  return (
    <div style={styles.container}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Cement Products</h1>
        <Link to="/cart" style={{ position: 'relative', textDecoration: 'none', color: 'black' }}>
          <i className="fa fa-shopping-cart" style={{ fontSize: '24px' }}></i>
          {cartCount > 0 && (
            <span
              style={{
                position: 'absolute',
                top: '-10px',
                right: '-10px',
                backgroundColor: 'red',
                color: 'white',
                borderRadius: '50%',
                padding: '5px 10px',
                fontSize: '12px',
              }}
            >
              {cartCount}
            </span>
          )}
        </Link>
      </nav>
      <div style={styles.grid}>
        {cementProducts.map((product) => (
          <div key={product.id} style={styles.card}>
            <img src={product.image} alt={product.name} style={styles.image} />
            <h2 style={styles.productName}>{product.name}</h2>
            <p style={styles.productBrand}>Brand: {product.brand}</p>
            <p style={styles.productPrice}>Price: {product.price}</p>
            <button
              style={styles.button}
              onClick={() => handleAddToCart(product)}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = styles.buttonHover.backgroundColor;
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = styles.button.backgroundColor;
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cement;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { API_URLS } from '../config/api';

const Tile = () => {
  const [cartCount, setCartCount] = useState(0);

  const tileProducts = [
    { id: 'tile1', name: 'Ceramic Tile', brand: 'Ceramic', price: '200 Rs', image: 'https://images.orientbell.com/media/catalog/product/c/r/craftclad_mosaic_4x8_grey_1.jpg' },
    { id: 'tile2', name: 'Porcelain Tile', brand: 'Porcelain', price: '250 Rs', image: 'https://www.deltaware.in//images/product/tiles-floor-1x1-matte_hu81e986848479647bc73125b0948b2562_59143_600x600_resize_q50_box.jpg' },
    { id: 'tile3', name: 'Mosaic Tile', brand: 'Mosaic', price: '300 Rs', image: 'https://corewebimage1.mytyles.biz/storage/prod/public/products/images/383c4de-cb3-784c-b838-2b2517cd4f4e/600x600.png' },
    { id: 'tile4', name: 'Granite Tile', brand: 'Granite', price: '350 Rs', image: 'https://media.istockphoto.com/id/176816406/photo/tile-flooring-samples-on-display.jpg?s=612x612&w=0&k=20&c=j3Q38Hj8eirmMn9cbncwDLGYd9e3BRQxEqTIOOE92vg=' },
    { id: 'tile5', name: 'Marble Tile', brand: 'Marble', price: '400 Rs', image: 'https://cdn.magicdecor.in/com/2023/02/29210213/image-1686032246-7362-710x488.jpg' },
    { id: 'tile6', name: 'Ceramic Tile', brand: 'Ceramic', price: '220 Rs', image: 'https://garden.spoonflower.com/c/6976236/p/f/m/KdB5EiDnu6vpPc4T1ZeVv-a1ClnkPCAZkdz2Gxqkx5Zab3dlTZBJL-8ej2U/leaf%20tiles%20blush%20silver%20grey.jpg' },
    { id: 'tile7', name: 'Porcelain Tile', brand: 'Porcelain', price: '270 Rs', image: 'https://tileswale.com/uploads/products/164078470388_9195_580658.jpg' },
    { id: 'tile8', name: 'Mosaic Tile', brand: 'Mosaic', price: '320 Rs', image: 'https://i5.walmartimages.com/asr/a8d92878-4ae4-45d2-a02a-1a7f86e9a292.883f46bafb1f87d5048559b375e8b163.jpeg' },
    { id: 'tile9', name: 'Granite Tile', brand: 'Granite', price: '360 Rs', image: 'https://www.deltaware.in/images/blog/tiles/tiles-types-large_hua8000130a68119c3a8a96f07ac503858_72802_900x450_resize_q100_h2_box.webp' },
    { id: 'tile10', name: 'Marble Tile', brand: 'Marble', price: '410 Rs', image: 'https://www.wallsauce.com/432759/cr23/24/828/1/retro-mosaic-tiles-tile-effect-wallpaper.jpg' }
  ];

  const styles = {
    container: {
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      margin: '20px 0',
    },
    card: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '15px',
      textAlign: 'center',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    image: {
      width: '150px',
      height: '150px',
      borderRadius: '8px',
      marginBottom: '10px',
    },
    productName: {
      fontSize: '18px',
      fontWeight: 'bold',
      marginBottom: '10px',
    },
    productBrand: {
      fontSize: '16px',
      color: '#555',
      marginBottom: '10px',
    },
    productPrice: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#007BFF',
      marginBottom: '10px',
    },
    button: {
      padding: '10px 15px',
      backgroundColor: '#007BFF',
      color: 'white',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
  };

  useEffect(() => {
    const fetchCartCount = async () => {
      try {
        const response = await axios.get(`${API_URLS.CART}/count`);
        if (response.data.success) {
          setCartCount(response.data.count);
        }
      } catch (error) {
        console.error('Error fetching cart count:', error);
      }
    };
    fetchCartCount();
  }, []);

  // Handle Add to Cart
  const handleAddToCart = async (product) => {
    try {
      const cartItem = {
        productId: product.id, // Use the ID directly since it already includes the prefix
        productName: product.name,
        price: parseFloat(product.price.replace(' Rs', '')),
        quantity: 1,
        category: 'Tile',
        brand: product.brand,
        image: product.image
      };

      console.log('Sending cart item:', cartItem); // Debug log

      // Send to backend first
      const response = await axios.post(`${API_URLS.CART}/add`, cartItem);
      
      if (response.data.success) {
        // If backend call succeeds, update local count
        setCartCount((prevCount) => prevCount + 1);
        
        // Show success message
        alert('Product added to cart successfully!');
      } else {
        throw new Error(response.data.message || 'Failed to add item to cart');
      }
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart. Please try again.');
    }
  };

  return (
    <div style={styles.container}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Tile Products</h1>
        <Link to="/cart" style={{ position: 'relative', textDecoration: 'none', color: 'black' }}>
          <i className="fa fa-shopping-cart" style={{ fontSize: '24px' }}></i>
          {cartCount > 0 && (
            <span
              style={{
                position: 'absolute',
                top: '-10px',
                right: '-10px',
                backgroundColor: 'red',
                color: 'white',
                borderRadius: '50%',
                padding: '5px 10px',
                fontSize: '12px',
              }}
            >
              {cartCount}
            </span>
          )}
        </Link>
      </nav>
      <div style={styles.grid}>
        {tileProducts.map((product) => (
          <div key={product.id} style={styles.card}>
            <img src={product.image} alt={product.name} style={styles.image} />
            <h2 style={styles.productName}>{product.name}</h2>
            <p style={styles.productBrand}>Brand: {product.brand}</p>
            <p style={styles.productPrice}>Price: {product.price}</p>
            <button
              style={styles.button}
              onClick={() => handleAddToCart(product)}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = styles.buttonHover.backgroundColor;
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = styles.button.backgroundColor;
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Tile;

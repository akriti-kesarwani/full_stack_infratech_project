import React, { useState, useEffect } from 'react';
import styled, { keyframes, css, ThemeProvider } from 'styled-components';
import { motion, AnimatePresence, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import product1 from '../photos/product1.jpg';
import product2 from '../photos/product2.jpg';
import product3 from '../photos/product3.jpg';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import NotificationTest from '../components/NotificationTest';
import { requestNotificationPermission, onMessageListener } from '../firebase/config';

const theme = {
  primary: '#2563eb',
  primaryLight: '#60a5fa',
  primaryDark: '#1e40af',
  secondary: '#f43f5e',
  secondaryLight: '#fb7185', 
  accent: '#10b981',
  accentLight: '#34d399',
  background: '#f8fafc',
  backgroundDark: '#f1f5f9',
  text: '#0f172a',
  textLight: '#64748b',
  white: '#FFFFFF',
  shadows: {
    small: '0 2px 8px rgba(0,0,0,0.08)',
    medium: '0 4px 12px rgba(0,0,0,0.12)',
    large: '0 8px 24px rgba(0,0,0,0.15)',
    hover: '0 12px 32px rgba(0,0,0,0.18)'
  },
  gradients: {
    primary: 'linear-gradient(135deg, #2563eb 0%, #1e40af 100%)',
    secondary: 'linear-gradient(135deg, #f43f5e 0%, #e11d48 100%)',
    accent: 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
  }
};
const fadeIn = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px);
  }
  to { 
    opacity: 1; 
    transform: translateY(0);
  }
`;
const slideIn = keyframes`
  from {
    transform: translateX(-100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
`;
const pulse = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
`;
const InteractiveCard = styled(motion.div)`
  background: ${theme.white};
  border-radius: 12px;
  padding: 2rem;
  box-shadow: ${theme.shadows.medium};
  transition: all 0.3s ease;
  cursor: pointer;
  &:hover {
    box-shadow: ${theme.shadows.hover};
    transform: translateY(-5px);
  }
`;
const SearchOverlay = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 2rem;
`;
const EnhancedSearchBar = styled(motion.div)`
  background: ${theme.white};
  border-radius: 20px;
  padding: 2rem;
  width: 100%;
  max-width: 800px;
  box-shadow: ${theme.shadows.large};
  margin: 2rem auto;
  position: relative;
  border: 1px solid rgba(0, 0, 0, 0.05);
  backdrop-filter: blur(10px);
  input {
    width: 100%;
    padding: 1.2rem 1.5rem;
    border: 2px solid transparent;
    border-radius: 12px;
    font-size: 1.1rem;
    outline: none;
    transition: all 0.3s ease;
    background: ${theme.backgroundDark};
    color: ${theme.text};
    &:focus {
      border-color: ${theme.primary};
      background: ${theme.white};
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
    }
    &::placeholder {
      color: ${theme.textLight};
    }
  }
`;
const SearchSuggestions = styled(motion.div)`
  margin-top: 1.5rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
  padding: 0.5rem;
`;
const Suggestion = styled(motion.button)`
  background: ${theme.backgroundDark};
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 500;
  color: ${theme.text};
  display: flex;
  align-items: center;
  gap: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  &:hover {
    background: ${theme.primary};
    color: ${theme.white};
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(37, 99, 235, 0.2);
  }
  &:active {
    transform: translateY(-1px);
  }
`;
const HeroSection = styled.section`
  min-height: 100vh;
  background: ${theme.gradients.primary};
  color: ${theme.white};
  position: relative;
  overflow: hidden;
  padding: 8rem 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2V6h4V4H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    opacity: 0.1;
  }
  &::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    background: 
      radial-gradient(circle at 20% 30%, rgba(37, 99, 235, 0.2) 0%, transparent 50%),
      radial-gradient(circle at 80% 70%, rgba(244, 63, 94, 0.2) 0%, transparent 50%);
    pointer-events: none;
  }
`;
const CategoryGrid = styled(motion.div)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1400px;
  margin: 4rem auto;
`;
const CategoryCard = styled(InteractiveCard)`
  text-align: center;
  position: relative;
  overflow: hidden;
  padding: 2.5rem;
  background: linear-gradient(135deg, ${theme.white} 0%, ${theme.backgroundDark} 100%);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: ${theme.gradients.secondary};
  }
  h3 {
    font-size: 1.5rem;
    margin: 1rem 0;
    color: ${theme.text};
  }
  p {
    color: ${theme.textLight};
    font-size: 0.9rem;
  }
  .icon {
    font-size: 3rem;
    margin-bottom: 1rem;
  }
`;
const StatisticsSection = styled.section`
  padding: 6rem 2rem;
  background: ${theme.gradients.primary};
  color: ${theme.white};
`;
const StatGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 3rem;
  max-width: 1200px;
  margin: 0 auto;
`;
const StatCard = styled(motion.div)`
  text-align: center;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  backdrop-filter: blur(10px);
`;
const FeaturedProducts = styled.section`
  padding: 6rem 2rem;
  background: ${theme.white};
`;
const ProductGrid = styled(motion.div)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
`;
const ProductCard = styled(motion.div)`
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: ${theme.shadows.medium};
  img {
    width: 100%;
    height: 200px;
    object-fit: cover;
  }
  .content {
    padding: 1.5rem;
  }
  .placeholder {
    width: 100%;
    height: 200px;
    background: ${theme.backgroundDark};
    display: flex;
    align-items: center;
    justify-content: center;
    color: ${theme.textLight};
  }
`;
const TestimonialsSection = styled.section`
  padding: 6rem 2rem;
  background: ${theme.backgroundDark};
  overflow: hidden;
`;
const TestimonialCard = styled(motion.div)`
  background: ${theme.white};
  padding: 2rem;
  border-radius: 12px;
  box-shadow: ${theme.shadows.medium};
  max-width: 600px;
  margin: 0 auto;
  text-align: center;
`;
const CTASection = styled.section`
  padding: 8rem 2rem;
  text-align: center;
  background: ${theme.white};
  position: relative;
  overflow: hidden;
`;
const Button = styled(motion.button)`
  padding: ${props => props.large ? '1.2rem 3rem' : '1rem 2.5rem'};
  background: ${props => props.variant === 'outline' ? 'transparent' : 
    props.variant === 'gradient' ? theme.gradients.primary : theme.white};
  color: ${props => props.variant === 'outline' ? theme.white : 
    props.variant === 'gradient' ? theme.white : theme.primary};
  border: ${props => props.variant === 'outline' ? `2px solid ${theme.white}` : 'none'};
  border-radius: 50px;
  font-weight: 600;
  font-size: ${props => props.large ? '1.2rem' : '1rem'};
  cursor: pointer;
  transition: all 0.3s ease;
  letter-spacing: 0.5px;
  text-transform: ${props => props.uppercase ? 'uppercase' : 'none'};
  position: relative;
  overflow: hidden;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      120deg,
      transparent,
      rgba(255, 255, 255, 0.2),
      transparent
    );
    transform: translateX(-100%);
    transition: 0.6s;
  }
  &:hover::before {
    transform: translateX(100%);
  }
  &:hover {
    transform: translateY(-3px);
    box-shadow: ${props => props.variant === 'outline' ? 
      '0 7px 14px rgba(255, 255, 255, 0.1)' : 
      '0 7px 14px rgba(0, 0, 0, 0.1)'};
    background: ${props => props.variant === 'outline' ? 
      'rgba(255, 255, 255, 0.1)' : 
      props.variant === 'gradient' ? 
        theme.gradients.secondary : 
        theme.white};
  }
  &:active {
    transform: translateY(-1px);
  }
  svg {
    width: 20px;
    height: 20px;
  }
`;
const HomeContainer = styled.div`
  min-height: 100vh;
  width: 100%;
  overflow-x: hidden;
  background: ${props => props.theme.background};
  scroll-behavior: smooth;
  * {
    scroll-behavior: smooth;
  }
`;
const WhatsAppBar = styled(motion.div)`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #fff;
  border-radius: 15px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  width: 300px;
  overflow: hidden;
  z-index: 1000;
`;
const WhatsAppHeader = styled.div`
  background: #075e54;
  color: white;
  padding: 15px;
  display: flex;
  align-items: center;
  gap: 10px;
  
  .profile-pic {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #128C7E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
  }
  
  .info {
    flex: 1;
    h3 {
      margin: 0;
      font-size: 16px;
    }
    p {
      margin: 0;
      font-size: 12px;
      opacity: 0.8;
    }
  }
`;
const WhatsAppBody = styled.div`
  padding: 15px;
  background: #e5ddd5;
  min-height: 100px;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;
const WhatsAppMessage = styled.div`
  background: white;
  padding: 10px 15px;
  border-radius: 7.5px;
  max-width: 80%;
  align-self: flex-start;
  font-size: 14px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -10px;
    border: 5px solid transparent;
    border-right-color: white;
    border-top-color: white;
  }
`;
const WhatsAppFooter = styled.div`
  padding: 15px;
  background: #f0f0f0;
  display: flex;
  gap: 10px;
  align-items: center;
  
  button {
    background: #25d366;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 20px;
    cursor: pointer;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
    transition: all 0.2s ease;
    
    &:hover {
      background: #128C7E;
    }
  }
`;
const FloatingElement = styled(motion.div)`
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5px);
  z-index: 1;
`;
const BrandLogo = styled(motion.div)`
  padding: 1.2rem 2rem;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.15);
  font-weight: 800;
  font-size: 1.25rem;
  letter-spacing: 1px;
  transition: all 0.3s ease;
  &:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  }
  &::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 12px;
    padding: 1px;
    background: linear-gradient(
      to bottom right,
      rgba(255, 255, 255, 0.2),
      rgba(255, 255, 255, 0.05)
    );
    -webkit-mask: linear-gradient(#fff 0 0) content-box,
                 linear-gradient(#fff 0 0);
    mask: linear-gradient(#fff 0 0) content-box,
          linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    pointer-events: none;
  }
`;
const Footer = styled.footer`
  background: ${theme.backgroundDark};
  padding: 6rem 2rem 2rem;
  color: ${theme.text};
`;
const FooterGrid = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 4rem;
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
`;
const FooterColumn = styled.div`
  h3 {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    color: ${theme.text};
  }
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  li {
    margin-bottom: 0.8rem;
  }
  a {
    color: ${theme.textLight};
    text-decoration: none;
    transition: all 0.3s ease;
    font-size: 0.95rem;
    &:hover {
      color: ${theme.primary};
    }
  }
`;
const FooterBottom = styled.div`
  margin-top: 4rem;
  padding-top: 2rem;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
`;
const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;
  a {
    color: ${theme.textLight};
    transition: all 0.3s ease;
    &:hover {
      color: ${theme.primary};
      transform: translateY(-2px);
    }
  }
`;
const NotificationPopup = styled(motion.div)`
  position: fixed;
  top: 20px;
  right: 20px;
  background: ${theme.white};
  border-radius: 12px;
  padding: 1rem;
  box-shadow: ${theme.shadows.medium};
  z-index: 1000;
  h4 {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
  }
  p {
    font-size: 0.9rem;
    margin-bottom: 1rem;
  }
  button {
    position: absolute;
    top: 10px;
    right: 10px;
    background: transparent;
    border: none;
    cursor: pointer;
    font-size: 1.2rem;
  }
`;

const Home = () => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const controls = useAnimation();
  const [ref, inView] = useInView();
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const [notification, setNotification] = useState(null);
  const [showWhatsApp, setShowWhatsApp] = useState(false);

  const categories = [
    { id: 'steel', name: 'Steel & TMT', icon: '🏗️', count: '2,500+ Products' },
    { id: 'cement', name: 'Cement', icon: '🏢', count: '1,000+ Products' },
    { id: 'chemicals', name: 'Construction Chemicals', icon: '⚗️', count: '3,000+ Products' },
    { id: 'tiles', name: 'Tiles & Flooring', icon: '🏠', count: '5,000+ Products' }
  ];
  const featuredProducts = [
    { id: 1, name: 'Premium Steel TMT Bars', price: '₹52,000/ton', tag: 'Best Seller' },
    { id: 2, name: 'Ultra Tech Cement', price: '₹380/bag', tag: 'New' },
    { id: 3, name: 'Waterproofing Solution', price: '₹2,500/unit', tag: 'Trending' }
  ];
  const testimonials = [
    {
      text: "InfraTrack has transformed how we source materials. Highly recommended!",
      author: "Rajesh Kumar",
      position: "Project Manager, Constructions"
    },
    {
      text: "The quality and reliability of products is exceptional. Great platform!",
      author: "Priya Singh",
      position: "Director, XYZ Builders"
    }
  ];

  useEffect(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);

  useEffect(() => {
    const init = async () => {
      try {
        // Simulate loading
        await new Promise(resolve => setTimeout(resolve, 1000));
        setIsLoading(false);
      } catch (error) {
        console.error('Error during initialization:', error);
        setIsLoading(false);
      }
    }; 
    init();
  }, []);

  useEffect(() => {
    console.log('Home component mounted');
    return () => console.log('Home component unmounted');
  }, []);

  useEffect(() => {
    // Request notification permission when component mounts
    const initializeNotifications = async () => {
      const token = await requestNotificationPermission();
      if (token) {
        // Send token to your backend
        try {
          await fetch('http://localhost:3001/api/notifications/register', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token }),
          });
        } catch (error) {
          console.error('Error registering token:', error);
        }
      }
    };

    initializeNotifications();

    // Listen for incoming messages
    const unsubscribe = onMessageListener()
      .then((payload) => {
        setNotification({
          title: payload.notification.title,
          body: payload.notification.body,
        });
        
        // Auto-hide notification after 5 seconds
        setTimeout(() => {
          setNotification(null);
        }, 5000);
      })
      .catch((err) => console.error('Error receiving message:', err));

    return () => unsubscribe;
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    const query = searchQuery.toLowerCase();

    // Define product categories and their keywords
    const categories = {
      steel: ['steel', 'iron', 'metal', 'tmt', 'rod', 'bar'],
      wood: ['wood', 'timber', 'plywood', 'lumber', 'board', 'panel'],
      cement: ['cement', 'concrete', 'mortar', 'binding'],
      sand: ['sand', 'aggregate', 'silica', 'river sand', 'm-sand'],
      tile: ['tile', 'ceramic', 'porcelain', 'floor tile', 'wall tile'],
      plumbing: ['plumbing', 'pipe', 'tap', 'faucet', 'valve', 'fitting']
    };

    // Find matching category
    const matchedCategory = Object.entries(categories).find(([_, keywords]) =>
      keywords.some(keyword => query.includes(keyword))
    );

    if (matchedCategory) {
      navigate(`/products/${matchedCategory[0]}`);
    } else {
      alert('No matching products found. Try searching for steel, wood, cement, sand, tile, or plumbing items.');
    }
  };

  const handleWhatsAppClick = () => {
    if (showWhatsApp) {
      // If chat is open, proceed with WhatsApp redirect
      const phoneNumber = '916392627322';
      const message = 'Hi, I would like to know more about your products';
      const whatsappUrl = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
      setShowWhatsApp(false);
    } else {
      // If chat is closed, show the chat interface
      setShowWhatsApp(true);
    }
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <ErrorBoundary>
      <ThemeProvider theme={theme}>
        <AnimatePresence>
          <HomeContainer>
            <NotificationTest />
            <HeroSection>
              <FloatingElement
                style={{
                  width: '200px',
                  height: '200px',
                  top: '10%',
                  left: '5%',
                }}
                animate={{
                  y: [0, 30, 0],
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 20,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
              <FloatingElement
                style={{
                  width: '150px',
                  height: '150px',
                  bottom: '10%',
                  right: '5%',
                }}
                animate={{
                  y: [0, -30, 0],
                  rotate: [360, 0],
                }}
                transition={{
                  duration: 15,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                style={{ 
                  maxWidth: '800px', 
                  textAlign: 'center',
                  position: 'relative',
                  zIndex: 10
                }}
              >
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  style={{
                    background: 'rgba(255, 255, 255, 0.1)',
                    padding: '0.5rem 1rem',
                    borderRadius: '20px',
                    display: 'inline-block',
                    marginBottom: '1rem',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255, 255, 255, 0.2)'
                  }}
                >
                  🏗️ India's #1 Construction Materials Marketplace
                </motion.div>
                <h1 style={{ 
                  fontSize: '4rem', 
                  marginBottom: '1.5rem',
                  background: 'linear-gradient(to right, #fff, #f0f0f0)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  textShadow: '0 2px 10px rgba(0,0,0,0.1)'
                }}>
                  Source Construction Materials <br/>
                  <span style={{ 
                    background: 'linear-gradient(to right, #ffd700, #ff8c00)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent'
                  }}>
                    Directly from Suppliers
                  </span>
                </h1>
                <p style={{ 
                  fontSize: '1.5rem', 
                  marginBottom: '2rem',
                  color: 'rgba(255, 255, 255, 0.9)'
                }}>
                  Connect with 10,000+ verified suppliers for TMT bars, cement, tiles, and more
                </p>
                <EnhancedSearchBar
                  initial={false}
                  style={{ 
                    marginBottom: '2rem',
                    position: 'relative',
                    zIndex: 20
                  }}
                >
                  <form onSubmit={handleSearch}>
                    <input
                      type="text"
                      placeholder="Search for TMT bars, cement, tiles, chemicals..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '1rem',
                        border: 'none',
                        fontSize: '1.1rem',
                        outline: 'none',
                        borderRadius: '8px',
                        position: 'relative',
                        zIndex: 30
                      }}
                    />
                  </form>
                  <SearchSuggestions>
                    {categories.map((category) => (
                      <Suggestion
                        key={category.id}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setActiveCategory(category.id)}
                      >
                        {category.icon} {category.name}
                      </Suggestion>
                    ))}
                  </SearchSuggestions>
                </EnhancedSearchBar>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  style={{
                    display: 'flex',
                    justifyContent: 'center',
                    gap: '2rem',
                    marginTop: '2rem',
                    color: 'rgba(255, 255, 255, 0.9)',
                    fontSize: '0.9rem'
                  }}
                >
                  <div>✓ 50,000+ Verified Products</div>
                  <div>✓ Bulk Order Discounts</div>
                  <div>✓ Pan India Delivery</div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 }}
                  style={{
                    marginTop: '2rem',
                    fontSize: '0.9rem',
                    color: 'rgba(255, 255, 255, 0.7)'
                  }}
                >
                  <span style={{ marginRight: '1rem' }}>Popular:</span>
                  {['TMT Bars', 'Portland Cement', 'Vitrified Tiles', 'Construction Chemicals'].map((term, index) => (
                    <motion.span
                      key={index}
                      whileHover={{ color: theme.white }}
                      style={{
                        marginRight: '1rem',
                        cursor: 'pointer',
                        textDecoration: 'underline'
                      }}
                    >
                      {term}
                    </motion.span>
                  ))}
                </motion.div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.9 }}
                  style={{
                    marginTop: '3rem',
                    padding: '2rem',
                    background: 'rgba(255, 255, 255, 0.05)',
                    borderRadius: '20px',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255, 255, 255, 0.1)'
                  }}
                >
                  <div style={{ color: 'rgba(255, 255, 255, 0.7)', marginBottom: '1rem' }}>
                    Trusted by leading manufacturers
                  </div>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    width: '100%',
                    maxWidth: '1200px',
                    margin: '0 auto',
                    padding: '2rem',
                    gap: '1.5rem'
                  }}>
                    {[
                      'TATA STEEL',
                      'ULTRATECH',
                      'KAJARIA',
                    ].map((brand, index) => (
                      <BrandLogo
                        key={index}
                        whileHover={{ 
                          scale: 1.02,
                          transition: { type: "spring", stiffness: 300 }
                        }}
                        whileTap={{ scale: 0.98 }}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ 
                          delay: index * 0.1,
                          duration: 0.5,
                          ease: "easeOut"
                        }}
                        style={{
                          flex: '1',
                          minWidth: '200px',
                          margin: '0 10px'
                        }}
                      >
                        {brand}
                      </BrandLogo>
                    ))}
                  </div>
                </motion.div>
              </motion.div>
            </HeroSection>
            <CategoryGrid>
              {categories.map((category, index) => (
                <CategoryCard
                  key={category.id}
                  whileHover={{ y: -10 }}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>
                    {category.icon}
                  </div>
                  <h3>{category.name}</h3>
                  <p style={{ color: theme.textLight }}>{category.count}</p>
                </CategoryCard>
              ))}
            </CategoryGrid>

            <StatisticsSection>
              <StatGrid>
                {[
                  { number: "10M+", label: "Products Delivered" },
                  { number: "50K+", label: "Happy Customers" },
                  { number: "1000+", label: "Verified Suppliers" },
                  { number: "100+", label: "Cities Covered" }
                ].map((stat, index) => (
                  <StatCard
                    key={index}
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <h2 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>
                      {stat.number}
                    </h2>
                    <p>{stat.label}</p>
                  </StatCard>
                ))}
              </StatGrid>
            </StatisticsSection>
            <FeaturedProducts>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                style={{
                  textAlign: 'center',
                  marginBottom: '3rem',
                  fontSize: '2.5rem',
                  fontWeight: '700',
                  color: theme.text
                }}
              >
                Featured Products
              </motion.h2>
              <ProductGrid>
                {[
                  {
                    id: 1,
                    name: 'Premium Steel TMT Bars',
                    price: '₹52,000/ton',
                    description: 'High-grade construction steel bars',
                    image: product1
                  },
                  {
                    id: 2,
                    name: 'Ultra Tech Cement',
                    price: '₹380/bag',
                    description: 'Portland Pozzolana Cement (PPC)',
                    image: product2
                  },
                  {
                    id: 3,
                    name: 'Waterproofing Solution',
                    price: '₹2,500/unit',
                    description: 'Advanced waterproofing compound',
                    image: product3
                  }
                ].map((product) => (
                  <ProductCard
                    key={product.id}
                    whileHover={{ y: -10 }}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <div style={{ position: 'relative', paddingTop: '66.67%', overflow: 'hidden' }}>
                      <img
                        src={product.image}
                        alt={product.name}
                        style={{
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          borderRadius: '12px 12px 0 0'
                        }}
                        onError={(e) => {
                          e.target.src = 'https://via.placeholder.com/400x300?text=Product+Image';
                        }}
                      />
                    </div>
                    <div className="content" style={{ padding: '1.5rem' }}>
                      <h3 style={{ 
                        fontSize: '1.25rem', 
                        fontWeight: '600',
                        marginBottom: '0.5rem',
                        color: theme.text
                      }}>
                        {product.name}
                      </h3>
                      <p style={{ 
                        color: theme.textLight,
                        marginBottom: '1rem',
                        fontSize: '0.9rem'
                      }}>
                        {product.description}
                      </p>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                      }}>
                        <span style={{ 
                          color: theme.primary,
                          fontWeight: '600',
                          fontSize: '1.1rem'
                        }}>
                          {product.price}
                        </span>
                        <Button
                          variant="outline"
                          style={{ padding: '0.5rem 1rem' }}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                  </ProductCard>
                ))}
              </ProductGrid>
            </FeaturedProducts>

            <TestimonialsSection>
              <h2 style={{ textAlign: 'center', marginBottom: '3rem' }}>
                What Our Clients Say
              </h2>
              <AnimatePresence mode='wait'>
                <TestimonialCard
                  key={currentTestimonial}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                >
                  <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
                    "{testimonials[currentTestimonial].text}"
                  </p>
                  <h4>{testimonials[currentTestimonial].author}</h4>
                  <p style={{ color: theme.textLight }}>
                    {testimonials[currentTestimonial].position}
                  </p>
                </TestimonialCard>
              </AnimatePresence>
              <div style={{ 
                display: 'flex', 
                justifyContent: 'center', 
                gap: '1rem', 
                marginTop: '2rem' 
              }}>
                {testimonials.map((_, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    whileHover={{ scale: 1.2 }}
                    style={{
                      width: '12px',
                      height: '12px',
                      borderRadius: '50%',
                      border: 'none',
                      background: currentTestimonial === index ? theme.primary : theme.backgroundDark,
                      cursor: 'pointer'
                    }}
                  />
                ))}
              </div>
            </TestimonialsSection>

            <CTASection>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h2 style={{ 
                  fontSize: '3.5rem', 
                  marginBottom: '1.5rem',
                  color: theme.text,
                  fontWeight: '700',
                  lineHeight: '1.2'
                }}>
                  Ready to Transform Your 
                  <span style={{ 
                    color: theme.primary,
                    display: 'block'
                  }}>
                    Construction Business?
                  </span>
                </h2>
                <p style={{ 
                  fontSize: '1.2rem', 
                  marginBottom: '2.5rem', 
                  maxWidth: '600px', 
                  margin: '0 auto 2.5rem',
                  color: theme.textLight
                }}>
                  Join thousands of businesses already sourcing construction materials through our platform
                </p>
                <Button
                  variant="gradient"
                  large
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Get Started Now
                </Button>
              </motion.div>
            </CTASection>

            <AnimatePresence>
              {showWhatsApp && (
                <WhatsAppBar
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 50 }}
                >
                  <WhatsAppHeader>
                    <div className="profile-pic">
                      <i className="fas fa-user"></i>
                    </div>
                    <div className="info">
                      <h3>InfraTrack Support</h3>
                      <p>Usually replies instantly</p>
                    </div>
                    <motion.button
                      style={{
                        background: 'none',
                        border: 'none',
                        color: 'white',
                        cursor: 'pointer',
                        padding: '5px'
                      }}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setShowWhatsApp(false)}
                    >
                      <i className="fas fa-times"></i>
                    </motion.button>
                  </WhatsAppHeader>
                  <WhatsAppBody>
                    <WhatsAppMessage>
                      Hello! 👋 How can we help you today?
                    </WhatsAppMessage>
                  </WhatsAppBody>
                  <WhatsAppFooter>
                    <button onClick={handleWhatsAppClick}>
                      <i className="fab fa-whatsapp"></i>
                      Connect
                    </button>
                  </WhatsAppFooter>
                </WhatsAppBar>
              )}
            </AnimatePresence>

            <motion.button
              style={{
                position: 'fixed',
                bottom: '20px',
                right: '20px',
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                background: '#25d366',
                color: theme.white,
                border: 'none',
                boxShadow: theme.shadows.medium,
                cursor: 'pointer',
                zIndex: 1000,
                display: showWhatsApp ? 'none' : 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '24px'
              }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowWhatsApp(true)}
            >
              <i className="fab fa-whatsapp"></i>
            </motion.button>
            <AnimatePresence>
              {searchOpen && (
                <SearchOverlay
                  role="dialog"
                  aria-label="Search"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSearchOpen(false)}
                >
                  <EnhancedSearchBar
                    onClick={(e) => e.stopPropagation()}
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                  >
                    <form onSubmit={handleSearch}>
                      <input
                        type="text"
                        placeholder="Search products, suppliers, or materials..."
                        autoFocus
                        style={{
                          width: '100%',
                          padding: '1rem',
                          border: 'none',
                          borderRadius: '8px',
                          fontSize: '1.1rem',
                          outline: 'none'
                        }}
                      />
                    </form>
                    <SearchSuggestions>
                      {categories.map((category) => (
                        <Suggestion
                          key={category.id}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {category.icon} {category.name}
                        </Suggestion>
                      ))}
                    </SearchSuggestions>
                  </EnhancedSearchBar>
                </SearchOverlay>
              )}
            </AnimatePresence>
            {notification && (
              <NotificationPopup
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                transition={{ duration: 0.3 }}
              >
                <h4>{notification.title}</h4>
                <p>{notification.body}</p>
                <button onClick={() => setNotification(null)}>×</button>
              </NotificationPopup>
            )}
            <Footer>
              <FooterGrid>
                <FooterColumn>
                  <p style={{ 
                    color: theme.textLight, 
                    marginBottom: '2rem', 
                    lineHeight: '1.6',
                    fontSize: '0.95rem'
                  }}>
                    India's leading B2B marketplace for construction materials. 
                    Connecting suppliers with businesses across the country.
                  </p>
                  <SocialLinks>
                    <a href="#" aria-label="LinkedIn">
                      <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                      </svg>
                    </a>
                    <a href="#" aria-label="Twitter">
                      <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                      </svg>
                    </a>
                    <a href="#" aria-label="Facebook">
                      <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M9 8h-3v4h3v12h5v-12h3v-4h-3V8h-5z"/>
                      </svg>
                    </a>
                  </SocialLinks>
                </FooterColumn>
                <FooterColumn>
                  <h3>Products</h3>
                  <ul>
                    <li><a href="#">Steel & TMT</a></li>
                    <li><a href="#">Cement</a></li>
                    <li><a href="#">Construction Chemicals</a></li>
                    <li><a href="#">Tiles & Flooring</a></li>
                    <li><a href="#">View All Categories</a></li>
                  </ul>
                </FooterColumn>
                <FooterColumn>
                  <h3>Company</h3>
                  <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Partner With Us</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Press & Media</a></li>
                  </ul>
                </FooterColumn>
                <FooterColumn>
                  <h3>Support</h3>
                  <ul>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Shipping Policy</a></li>
                  </ul>
                </FooterColumn>
              </FooterGrid>
              <FooterBottom>
                <div style={{ color: theme.textLight }}>
                  &copy; 2024 IntraMarkt. All rights reserved.
                </div>
                <div style={{ display: 'flex', gap: '2rem' }}>
                  <a href="#" style={{ color: theme.textLight, textDecoration: 'none' }}>Privacy Policy</a>
                  <a href="#" style={{ color: theme.textLight, textDecoration: 'none' }}>Terms of Service</a>
                </div>
              </FooterBottom>
            </Footer>
          </HomeContainer>
        </AnimatePresence>
      </ThemeProvider>
    </ErrorBoundary>
  );
};

Home.propTypes = {
};

export default React.memo(Home);

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return <h1>Something went wrong.</h1>;
    }
    return this.props.children;
  }
}

const LoadingSpinner = () => (
  <div style={{
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    background: theme.background
  }}>
    <motion.div
      style={{
        width: 50,
        height: 50,
        border: `5px solid ${theme.primaryLight}`,
        borderTop: `5px solid ${theme.primary}`,
        borderRadius: '50%'
      }}
      animate={{ rotate: 360 }}
      transition={{
        duration: 1,
        repeat: Infinity,
        ease: "linear"
      }}
    />
  </div>
);

const IMAGES = {
  product1,
  product2,
  product3,
};

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import steel1 from './images/steel/steel1.webp';
import steel2 from './images/steel/steel2.webp';
import steel3 from './images/steel/steel3.avif';
import steel4 from './images/steel/steel4.webp';
import steel5 from './images/steel/ssteel5.jpg';
import steel6 from './images/steel/steel6.jpg';
import steel7 from './images/steel/steel7.jpg';
import steel8 from './images/steel/steel8.jpg';

const Steel = () => {
  const [cartCount, setCartCount] = useState(0);

  const steelProducts = [
    { id: 'steel1', name: 'TMT Bars', brand: 'Tata Steel', price: '5000 Rs', image: steel1 },
    { id: 'steel2', name: 'Structural Steel', brand: 'JSW Steel', price: '4500 Rs', image: steel2 },
    { id: 'steel3', name: 'Steel Plates', brand: 'SAIL', price: '6000 Rs', image: steel3 },
    { id: 'steel4', name: 'Steel Pipes', brand: 'APL Apollo', price: '3500 Rs', image: steel4 },
    { id: 'steel5', name: 'Steel Sheets', brand: 'Jindal Steel', price: '4000 Rs', image: steel5 },
    { id: 'steel6', name: 'Steel Angles', brand: 'Essar Steel', price: '3000 Rs', image: steel6 },
    { id: 'steel7', name: 'Steel Channels', brand: 'RINL', price: '3800 Rs', image: steel7 },
    { id: 'steel8', name: 'Steel Beams', brand: 'Bhushan Steel', price: '5500 Rs', image: steel8 }
  ];

  const styles = {
    container: {
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      margin: '20px 0',
    },
    card: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '15px',
      textAlign: 'center',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    image: {
      width: '150px',
      height: '150px',
      borderRadius: '8px',
      marginBottom: '10px',
      objectFit: 'cover',
    },
    productName: {
      fontSize: '18px',
      fontWeight: 'bold',
      marginBottom: '10px',
    },
    productBrand: {
      fontSize: '16px',
      color: '#555',
      marginBottom: '10px',
    },
    productPrice: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#007BFF',
      marginBottom: '10px',
    },
    button: {
      padding: '10px 15px',
      backgroundColor: '#007BFF',
      color: 'white',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
  };

  const handleAddToCart = async (product) => {
    try {
      // Format the price correctly
      const priceString = product.price.replace(' Rs', '');
      const priceNumber = parseFloat(priceString);
      
      if (isNaN(priceNumber)) {
        throw new Error('Invalid price format');
      }

      const cartItem = {
        productId: product.id,
        productName: product.name,
        price: priceNumber,
        quantity: 1,
        category: 'Steel',
        brand: product.brand,
        image: product.image
      };

      console.log('Sending cart item:', cartItem);

      const response = await axios.post('/api/cart/add', cartItem);
      
      if (response.data.success) {
        console.log('Add to cart response:', response.data);
        setCartCount(prevCount => prevCount + 1);
        alert('Product added to cart successfully!');
      } else {
        throw new Error(response.data.message || 'Failed to add item to cart');
      }
    } catch (error) {
      console.error('Error adding item to cart:', error.response || error);
      let errorMessage = 'Failed to add item to cart. Please try again.';
      
      if (!navigator.onLine) {
        errorMessage = 'You appear to be offline. Please check your internet connection.';
      } else if (error.response) {
        errorMessage = error.response.data?.message || errorMessage;
      }
      
      alert(errorMessage);
    }
  };

  useEffect(() => {
    const fetchCartCount = async () => {
      try {
        const response = await axios.get('/api/cart/count');
        console.log('Cart count response:', response.data);
        if (response.data.success) {
          setCartCount(response.data.count);
        }
      } catch (error) {
        console.error('Error fetching cart count:', error);
      }
    };

    fetchCartCount();
  }, []);

  return (
    <div style={styles.container}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Steel Products</h1>
        <Link to="/cart" style={{ position: 'relative', textDecoration: 'none', color: 'black' }}>
          <i className="fa fa-shopping-cart" style={{ fontSize: '24px' }}></i>
          {cartCount > 0 && (
            <span
              style={{
                position: 'absolute',
                top: '-10px',
                right: '-10px',
                backgroundColor: 'red',
                color: 'white',
                borderRadius: '50%',
                padding: '5px 10px',
                fontSize: '12px',
              }}
            >
              {cartCount}
            </span>
          )}
        </Link>
      </nav>
      <div style={styles.grid}>
        {steelProducts.map((product) => (
          <div key={product.id} style={styles.card}>
            <img src={product.image} alt={product.name} style={styles.image} />
            <h2 style={styles.productName}>{product.name}</h2>
            <p style={styles.productBrand}>Brand: {product.brand}</p>
            <p style={styles.productPrice}>Price: {product.price}</p>
            <button 
              onClick={() => handleAddToCart(product)} 
              style={styles.button}
              onMouseOver={(e) => e.target.style.backgroundColor = styles.buttonHover.backgroundColor}
              onMouseOut={(e) => e.target.style.backgroundColor = styles.button.backgroundColor}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Steel;

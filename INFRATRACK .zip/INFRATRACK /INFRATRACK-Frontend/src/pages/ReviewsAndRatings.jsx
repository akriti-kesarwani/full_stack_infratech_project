import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FaStar } from 'react-icons/fa';
import { useLocation, useNavigate } from 'react-router-dom';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const ReviewList = styled.div`
  margin-top: 2rem;
`;

const ReviewItem = styled.div`
  background: #f9f9f9;
  padding: 1rem;
  margin-bottom: 1rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
`;

const Rating = styled.div`
  display: flex;
  gap: 0.2rem;
  color: #f39c12;
`;

const AddReviewForm = styled.form`
  background: #fff;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-top: 2rem;
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 0.8rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-bottom: 1rem;
  resize: vertical;
`;

const SubmitButton = styled.button`
  background-color: #3498db;
  color: white;
  border: none;
  padding: 0.8rem 2rem;
  font-size: 1rem;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background-color: #2980b9;
  }
`;

const ReviewsAndRatings = () => {
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState('');
  const [rating, setRating] = useState(0);
  const [averageRating, setAverageRating] = useState(0);
  const [userAuthenticated, setUserAuthenticated] = useState(true); // Assume the user is authenticated

  const location = useLocation();
  const navigate = useNavigate();

  // Mock data: in a real application, fetch this from an API or database
  const supplierId = location.pathname.split('/').pop(); // Assume the last segment of the URL is the supplier ID
  const sampleReviews = [
    { username: 'John Doe', rating: 4, comment: 'Great supplier, fast delivery!' },
    { username: 'Jane Smith', rating: 5, comment: 'Excellent quality materials!' },
    { username: 'Mike Johnson', rating: 3, comment: 'Okay, but the pricing is a bit high.' }
  ];

  useEffect(() => {
    // Calculate average rating
    const totalRating = sampleReviews.reduce((acc, review) => acc + review.rating, 0);
    const avgRating = totalRating / sampleReviews.length;
    setAverageRating(avgRating);
    setReviews(sampleReviews);
  }, []);

  const handleSubmitReview = (e) => {
    e.preventDefault();
    if (newReview.trim() === '') return; // Do not submit if review is empty

    // Add the new review (this would typically involve an API call)
    const newReviewObject = {
      username: 'Current User', // Replace with actual user's name
      rating,
      comment: newReview
    };

    setReviews([...reviews, newReviewObject]);
    setNewReview('');
    setRating(0);
  };

  const handleStarClick = (index) => {
    setRating(index + 1);
  };

  return (
    <Container>
      <h1>Reviews and Ratings for Supplier {supplierId}</h1>

      {/* Aggregated Rating */}
      <div style={{ marginTop: '2rem' }}>
        <h3>Average Rating: {averageRating.toFixed(1)} / 5</h3>
        <Rating>
          {[...Array(5)].map((_, index) => (
            <FaStar key={index} color={index < Math.round(averageRating) ? '#f39c12' : '#ccc'} />
          ))}
        </Rating>
      </div>

      {/* List of Reviews */}
      <ReviewList>
        {reviews.length > 0 ? (
          reviews.map((review, index) => (
            <ReviewItem key={index}>
              <h4>{review.username}</h4>
              <Rating>
                {[...Array(5)].map((_, index) => (
                  <FaStar key={index} color={index < review.rating ? '#f39c12' : '#ccc'} />
                ))}
              </Rating>
              <p>{review.comment}</p>
            </ReviewItem>
          ))
        ) : (
          <p>No reviews yet. Be the first to review!</p>
        )}
      </ReviewList>

      {/* Add New Review (For Authenticated Users) */}
      {userAuthenticated && (
        <AddReviewForm onSubmit={handleSubmitReview}>
          <h3>Add Your Review</h3>
          <div style={{ marginBottom: '1rem' }}>
            <Rating>
              {[...Array(5)].map((_, index) => (
                <FaStar
                  key={index}
                  onClick={() => handleStarClick(index)}
                  color={index < rating ? '#f39c12' : '#ccc'}
                  style={{ cursor: 'pointer' }}
                />
              ))}
            </Rating>
          </div>
          <TextArea
            value={newReview}
            onChange={(e) => setNewReview(e.target.value)}
            rows="4"
            placeholder="Write your review here..."
          />
          <SubmitButton type="submit">Submit Review</SubmitButton>
        </AddReviewForm>
      )}
    </Container>
  );
};

export default ReviewsAndRatings;

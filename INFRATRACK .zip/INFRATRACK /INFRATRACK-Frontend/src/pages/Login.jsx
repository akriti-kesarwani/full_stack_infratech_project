import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { theme } from '../theme';
import Logo from '../components/Logo';
import Navbar from '../components/common/Navbar';
import { AUTH_ENDPOINTS } from '../config/api';

const PageContainer = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  position: relative;
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  overflow: hidden;

  &::before,
  &::after {
    content: '';
    position: absolute;
    width: 1000px;
    height: 1000px;
    border-radius: 50%;
    background: linear-gradient(135deg, #60A5FA 0%, #3B82F6 100%);
    opacity: 0.1;
    animation: move 15s infinite linear;
  }

  &::before {
    top: -50%;
    left: -25%;
    animation-delay: -5s;
  }

  &::after {
    bottom: -50%;
    right: -25%;
  }

  @keyframes move {
    0% {
      transform: rotate(0deg) translate(50px) rotate(0deg);
    }
    100% {
      transform: rotate(360deg) translate(50px) rotate(-360deg);
    }
  }
`;

const FormContainer = styled(motion.div)`
  background: rgba(255, 255, 255, 0.95);
  padding: 3rem;
  border-radius: 24px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1), 0 0 0 1px rgba(0, 0, 0, 0.05);
  width: 100%;
  max-width: 480px;
  position: relative;
  overflow: hidden;
  backdrop-filter: blur(10px);
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: ${theme.gradients.primary};
  }

  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: -1;
    margin: -2px;
    border-radius: inherit;
    background: linear-gradient(
      to right bottom,
      rgba(255, 255, 255, 0.2),
      rgba(255, 255, 255, 0.05)
    );
  }
`;

const Title = styled.h1`
  font-size: 2.8rem;
  font-weight: 800;
  margin-bottom: 2rem;
  text-align: center;
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  letter-spacing: -0.5px;
`;

const Input = styled.input`
  width: 100%;
  padding: 1.2rem;
  margin-bottom: 1.5rem;
  border: 2px solid rgba(0, 0, 0, 0.05);
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
  background: rgba(255, 255, 255, 0.9);
  
  &:focus {
    outline: none;
    border-color: #3B82F6;
    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    background: white;
  }

  &::placeholder {
    color: #94A3B8;
  }
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1.2rem;
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 1rem;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  }
`;

const SocialButton = styled(motion.button)`
  width: 100%;
  padding: 1.2rem;
  background: white;
  border: 2px solid rgba(0, 0, 0, 0.05);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.8rem;
  cursor: pointer;
  margin-bottom: 1rem;
  font-weight: 500;
  color: #1F2937;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(59, 130, 246, 0.05);
    border-color: #3B82F6;
  }

  img {
    width: 24px;
    height: 24px;
  }
`;

const OrDivider = styled.div`
  display: flex;
  align-items: center;
  margin: 2rem 0;
  color: #94A3B8;
  font-weight: 500;
  
  &::before, &::after {
    content: '';
    flex: 1;
    height: 2px;
    background: rgba(0, 0, 0, 0.05);
  }
  
  span {
    padding: 0 1.5rem;
    font-size: 0.95rem;
  }
`;

const TextLink = styled(Link)`
  color: #3B82F6;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  
  &:hover {
    color: #2563EB;
    text-decoration: underline;
  }
`;

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await fetch(AUTH_ENDPOINTS.LOGIN, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        credentials: 'include',
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password: password
        }),
      });

      const data = await response.json();

      if (response.ok) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('userId', data.user._id); 
        localStorage.setItem('user', JSON.stringify(data.user));
        navigate('/');
      } else {
        setError(data.message || "Invalid email or password");
      }
    } catch (error) {
      console.error("Login error:", error);
      if (!navigator.onLine) {
        setError("You appear to be offline. Please check your internet connection.");
      } else {
        setError("Unable to connect to the server. Please make sure the backend server is running on port 5001.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = () => {
    // TODO: Implement Google Sign In
    setError("Google Sign In is not implemented yet");
  };

  return (
    <PageContainer>
      <Navbar />
      <Logo 
        style={{ 
          position: 'absolute',
          top: '20px', 
          left: '20px', 
          zIndex: 1000 
        }} 
      />
      <FormContainer
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Title>Welcome Back</Title>
        {error && <p style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <Input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            disabled={loading}
          />
          <Input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            disabled={loading}
          />
          <Button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loading}
          >
            {loading ? 'Logging in...' : 'Login'}
          </Button>
        </form>

        <OrDivider>
          <span>or</span>
        </OrDivider>

        <SocialButton
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleGoogleSignIn}
          disabled={loading}
        >
          <img src="https://www.google.com/favicon.ico" alt="Google" style={{ width: 20, height: 20 }} />
          Continue with Google
        </SocialButton>

        <p style={{ textAlign: 'center', marginTop: '2rem' }}>
          Don't have an account? <TextLink to="/signup">Sign up</TextLink>
        </p>
      </FormContainer>
    </PageContainer>
  );
};

export default Login;

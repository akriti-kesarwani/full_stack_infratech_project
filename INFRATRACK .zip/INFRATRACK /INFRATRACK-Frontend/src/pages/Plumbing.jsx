import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import plumb1 from './images/plumbing/plumb1.webp';
import plumb2 from './images/plumbing/plumb2.jpg';
import plumb3 from './images/plumbing/plumb3.webp';
import plumb4 from './images/plumbing/plumb4.jpg';
import plumb5 from './images/plumbing/plumb5.jpg';
import plumb6 from './images/plumbing/plumb6.jpg';

const Plumbing = () => {
  const [cartCount, setCartCount] = useState(0);

  const plumbingProducts = [
    { id: 'plumb1', name: 'PVC Pipe', brand: 'Astral', price: '300 Rs', image: plumb1 },
    { id: 'plumb2', name: 'Water Tank', brand: 'Sintex', price: '2000 Rs', image: plumb2 },
    { id: 'plumb3', name: 'Bathroom Fittings', brand: 'Jaguar', price: '1500 Rs', image: plumb3 },
    { id: 'plumb4', name: 'CPVC Pipe', brand: 'Supreme', price: '400 Rs', image: plumb4 },
    { id: 'plumb5', name: 'Water Pump', brand: 'Crompton', price: '3000 Rs', image: plumb5 },
    { id: 'plumb6', name: 'Tap Set', brand: 'Hindware', price: '800 Rs', image: plumb6 }
  ];

  const styles = {
    container: {
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      margin: '20px 0',
    },
    card: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '15px',
      textAlign: 'center',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    },
    image: {
      width: '150px',
      height: '150px',
      borderRadius: '8px',
      marginBottom: '10px',
      objectFit: 'cover',
    },
    productName: {
      fontSize: '18px',
      fontWeight: 'bold',
      marginBottom: '10px',
    },
    productBrand: {
      fontSize: '16px',
      color: '#555',
      marginBottom: '10px',
    },
    productPrice: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#007BFF',
      marginBottom: '10px',
    },
    button: {
      padding: '10px 15px',
      backgroundColor: '#007BFF',
      color: 'white',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
  };

  useEffect(() => {
    const fetchCartCount = async () => {
      try {
        const response = await axios.get('http://localhost:5001/api/cart/count');
        if (response.data.success) {
          setCartCount(response.data.count);
        }
      } catch (error) {
        console.error('Error fetching cart count:', error);
      }
    };
    fetchCartCount();
  }, []);

  const handleAddToCart = async (product) => {
    try {
      const cartItem = {
        productId: product.id,
        productName: product.name,
        price: parseFloat(product.price.replace(' Rs', '')),
        quantity: 1,
        category: 'Plumbing',
        brand: product.brand,
        image: product.image
      };

      console.log('Sending cart item:', cartItem);

      const response = await axios.post('http://localhost:5001/api/cart/add', cartItem);
      
      if (response.data.success) {
        setCartCount((prevCount) => prevCount + 1);
        alert('Product added to cart successfully!');
      } else {
        throw new Error(response.data.message || 'Failed to add item to cart');
      }
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart. Please try again.');
    }
  };

  return (
    <div style={styles.container}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Plumbing Products</h1>
        <Link to="/cart" style={{ position: 'relative', textDecoration: 'none', color: 'black' }}>
          <i className="fa fa-shopping-cart" style={{ fontSize: '24px' }}></i>
          {cartCount > 0 && (
            <span
              style={{
                position: 'absolute',
                top: '-10px',
                right: '-10px',
                backgroundColor: 'red',
                color: 'white',
                borderRadius: '50%',
                padding: '5px 10px',
                fontSize: '12px',
              }}
            >
              {cartCount}
            </span>
          )}
        </Link>
      </nav>
      <div style={styles.grid}>
        {plumbingProducts.map((product) => (
          <div key={product.id} style={styles.card}>
            <img src={product.image} alt={product.name} style={styles.image} />
            <h2 style={styles.productName}>{product.name}</h2>
            <p style={styles.productBrand}>Brand: {product.brand}</p>
            <p style={styles.productPrice}>Price: {product.price}</p>
            <button
              style={styles.button}
              onClick={() => handleAddToCart(product)}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = styles.buttonHover.backgroundColor;
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = styles.button.backgroundColor;
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Plumbing;

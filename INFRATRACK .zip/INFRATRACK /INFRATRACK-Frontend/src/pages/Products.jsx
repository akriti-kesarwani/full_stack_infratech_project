import React, { useState } from 'react';
import axios from 'axios'; // Import axios

const Products = () => {
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);  // State for selected product
  const [isModalOpen, setIsModalOpen] = useState(false);  // State to control modal visibility

  const products = [
    { id: 1, name: 'Cement', category: 'Building Materials', price: 50, link: '#cement', image: 'https://5.imimg.com/data5/LR/OI/MY-39094180/cement.jpg' },
    { id: 2, name: 'Steel Rods', category: 'Building Materials', price: 70, link: '#steelrods', image: 'https://images.jdmagicbox.com/quickquotes/images_main/jsw-steel-tmt-iron-rod-10mm-2219579413-onzglb7u.jpg' },
    { id: 3, name: 'Bricks', category: 'Building Materials', price: 120, link: '#bricks', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsi9GlSJie__AjcFZY-cgiMUM5LsFQWGh57w&s' },
    { id: 4, name: 'Construction Sand', category: 'Building Materials', price: 90, link: '#sands', image: 'https://happho.com/wp-content/uploads/2017/02/River-sand-1024x576.jpg' },
    { id: 5, name: 'Pipes', category: 'Plumbing', price: 30, link: '#pipes', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcVZ0UWiHdpbcPFYI8mBx9-ii6WcrWfzJVgwSvW-vKwSeNU3tLUCNZv74ZPcm3fFQztis&usqp=CAU' },
    { id: 6, name: 'Wire Cables', category: 'Electrical', price: 40, link: '#wires', image: 'https://i0.wp.com/www.anelectricalengineer.com/wp-content/uploads/2017/07/Cable-Classification-and-Specification.jpg?fit=1157%2C580&ssl=1' },
    { id: 7, name: 'PBC', category: 'Finishes', price: 20, link: '#pbc', image: 'https://5.imimg.com/data5/SELLER/Default/2024/5/419041216/VY/WP/OJ/47214240/pvc-wall-panel.webp' },
    { id: 8, name: 'Tiles', category: 'Flooring', price: 15, link: '#tiles', image: 'https://static.thcdn.com/productimg/300/300/13220601-1724924678126989.jpg' },
    { id: 9, name: 'Glass Sheets', category: 'Windows & Doors', price: 10, link: '#glass', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1Y9E7COaqBuIwQuX17F7SLNUFIWVbny1cJw&s' },
    { id: 10, name: 'Roofing Sheets', category: 'Roofing', price: 25, link: '#roofing', image: 'https://connect.buildnext.in/wp-content/uploads/2020/04/metalroofingsheets-169-1024x576.jpg' },
    { id: 11, name: 'Concrete', category: 'Concrete', price: 25, link: '#concrete', image:'https://australianslatecretesupplies.com.au/wp-content/uploads/2023/09/the-top-12-tools-you-will-need-when-working-with-concrete.jpg' },
    { id: 12, name: 'Concrete', category: 'Concrete', price: 25, link: '#concrete', image:'https://dcbyers.com/wp-content/uploads/2021/03/freshlypouredconcrete.jpeg' },
    { id: 13, name: 'Plumbing', category: 'Plumbing', price: 25, link: '#Plumbing', image:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7L7LA5CuNwXwbDegvFy8rcAGz9OoC0ccH-Q&s' },
    { id: 14, name: 'Electrical', category: 'Electrical', price: 25, link: '#Electrical', image:'https://www.topcable.com/blog-electric-cable/wp-content/uploads/2016/07/When-is-it-necessary-to-perform-the-alternate-flexions-test-2.jpg' },
    { id: 15, name: 'Finishes', category: 'Finishes', price: 25, link: '#Finishes', image:'https://eatonseating.com/images/features_finish-chart.jpg' },
    { id: 16, name: 'Windows & Doors', category: 'Windows & Doors', price: 25, link: '#Windows & Doors', image:'https://5.imimg.com/data5/SELLER/Default/2023/2/WI/GJ/AX/53635367/steel-doors-and-steel-windows.jpg' },
    { id: 17, name: 'Windows & Doors', category: 'Windows & Doors', price: 25, link: '#Windows & Doors', image:'https://www.period-homes.com/.image/t_share/MTUzMDY3NzU1MzQ2NjAxNTky/ph-doors-400.jpg' },
    { id: 18, name: 'Electrical', category: 'Electrical', price: 25, link: '#Electrical', image:'https://www.kei-ind.com/wp-content/uploads/2023/06/benefits-and-types-of-electrical-wire.jpg' },
    { id: 19, name: 'Building Materials', category: 'Building Materials', price: 25, link: '#Building Materials', image:'https://wordpress.bricknbolt.com/wp-content/uploads/2024/05/Building-materials-needed-to-build-a-house.webp' },
    { id: 20, name: 'Plumbing', category: 'Plumbing', price: 25, link: '#Plumbing', image:'https://media.hswstatic.com/eyJidWNrZXQiOiJjb250ZW50Lmhzd3N0YXRpYy5jb20iLCJrZXkiOiJnaWZcL3BsdW1iaW5nLWJhc2ljcy0zLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6ODI4fX19' },
  ];

  const categories = ['All', 'Building Materials', 'Plumbing', 'Electrical', 'Finishes', 'Flooring', 'Windows & Doors', 'Roofing'];

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  const handleAddToCart = async (product) => {
    try {
      // Add to local state
      setCart((prevCart) => [...prevCart, product]);
      
      // Send to backend
      await axios.post('http://localhost:5001/api/cart/add', {
        productId: product.id,
        productName: product.name,
        price: parseFloat(product.price),
        quantity: 1
      });
      
      // Show success message
      alert('Product added to cart successfully!');
    } catch (error) {
      console.error('Error adding item to cart:', error);
      alert('Failed to add item to cart. Please try again.');
    }
  };

  const openModal = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Infrastructure Market Products</h1>
      <div style={styles.searchBar}>
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={handleSearchChange}
          style={styles.searchInput}
        />
      </div>
      <div style={styles.categories}>
        <h2 style={styles.subHeading}>Categories</h2>
        <ul style={styles.categoryList}>
          {categories.map((category) => (
            <li
              key={category}
              style={styles.categoryItem}
              onClick={() => handleCategoryClick(category)}
            >
              {category}
            </li>
          ))}
        </ul>
      </div>
      <div style={styles.productList}>
        <h2 style={styles.subHeading}>Products</h2>
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <div key={product.id} style={styles.productCard} onClick={() => openModal(product)}>
              <img src={product.image} alt={product.name} style={styles.productImage} />
              <h3 style={styles.productName}>{product.name}</h3>
              <p style={styles.productDetails}>Category: {product.category}</p>
              <p style={styles.productDetails}>Price: ${product.price}</p>
              <a href={product.link} style={styles.productLink}>View Details</a>
              <button onClick={() => handleAddToCart(product)} style={styles.addToCartButton}>Add to Cart</button>
            </div>
          ))
        ) : (
          <p style={styles.noResults}>No products match your search.</p>
        )}
      </div>
      
      {/* Modal for product details */}
      {isModalOpen && selectedProduct && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <span style={styles.closeModal} onClick={closeModal}>&times;</span>
            <h2>{selectedProduct.name}</h2>
            <img src={selectedProduct.image} alt={selectedProduct.name} style={styles.modalImage} />
            <p><strong>Category:</strong> {selectedProduct.category}</p>
            <p><strong>Price:</strong> ${selectedProduct.price}</p>
            <p><strong>Details:</strong> <a href={selectedProduct.link} target="_blank" rel="noopener noreferrer">View More</a></p>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    width: '80%',
    margin: '0 auto',
    padding: '20px',
    backgroundColor: '#fff',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    fontFamily: 'Arial, sans-serif',
  },
  heading: {
    textAlign: 'center',
    color: '#333',
    marginBottom: '20px',
  },
  subHeading: {
    color: '#555',
    marginBottom: '10px',
  },
  searchBar: {
    marginBottom: '20px',
    textAlign: 'center',
  },
  searchInput: {
    padding: '10px',
    width: '50%',
    fontSize: '16px',
    borderRadius: '5px',
    border: '1px solid #ddd',
  },
  categories: {
    marginBottom: '30px',
  },
  categoryList: {
    listStyleType: 'none',
    padding: '0',
    margin: '0',
  },
  categoryItem: {
    display: 'inline-block',
    marginRight: '20px',
    fontWeight: 'bold',
    color: '#007BFF',
    cursor: 'pointer',
    padding: '5px',
  },
  productList: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: '30px',
  },
  productCard: {
    border: '1px solid #ddd',
    padding: '20px',
    marginBottom: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#fff',
    width: '23%',
    boxSizing: 'border-box',
    marginRight: '20px',
    marginBottom: '20px',
    cursor: 'pointer',
  },
  productImage: {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
    borderRadius: '8px',
    marginBottom: '15px',
  },
  productName: {
    color: '#333',
    marginBottom: '10px',
    fontSize: '18px',
  },
  productDetails: {
    color: '#777',
    marginBottom: '5px',
  },
  productLink: {
    color: '#007BFF',
    textDecoration: 'none',
    marginBottom: '10px',
    display: 'inline-block',
  },
  addToCartButton: {
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    display: 'inline-block',
  },
  noResults: {
    color: '#333',
    fontSize: '18px',
    textAlign: 'center',
    width: '100%',
  },
  cart: {
    marginTop: '40px',
  },
  cartList: {
    listStyleType: 'none',
    padding: '0',
  },
  cartItem: {
    color: '#333',
  },
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    width: '70%',
    maxWidth: '800px',
    textAlign: 'center',
  },
  closeModal: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    fontSize: '30px',
    cursor: 'pointer',
  },
  modalImage: {
    width: '100%',
    height: '300px',
    objectFit: 'cover',
    marginBottom: '20px',
  },
};

export default Products;

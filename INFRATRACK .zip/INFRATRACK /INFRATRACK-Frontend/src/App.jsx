import React from 'react';
import { ThemeProvider } from 'styled-components';
import { theme } from './theme';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/common/Navbar';
import Home from './pages/Home';
import Products from './pages/Products';
import Suppliers from './pages/Suppliers';
import Login from './pages/Login';
import Signup from './pages/Signup';
import './styles/global.css';
import About from './pages/About';
import CartPage from './pages/CartPage';

import Cement from './pages/Cement';
import Tile from './pages/Tile';
import Steel from './pages/Steel';
import Wood from './pages/Wood';
import Plumbing from './pages/Plumbing';
import Sand from './pages/Sand';
import FranchisePage from './pages/FranchisePage';
import SupplierList from './pages/SupplierList';
import SupplierProfilePage from './pages/SupplierProfilePage';
import AddSupplierPage from './pages/AddSupplierPage';
import ReviewsAndRatings from './pages/ReviewsAndRatings';
// import ProductDetails from './pages/ProductDetails';


function App() {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <div className="app">
          <Navbar />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/products" element={<Products />} />
              <Route path="/suppliers" element={<Suppliers />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/about" element={<About />} />
              <Route path="/cart" element={<CartPage />} />
              
              <Route path="/products/tile" element={<Tile />} />
              <Route path="/products/steel" element={<Steel />} />
              <Route path="/products/wood" element={<Wood />} />
              <Route path="/products/plumbing" element={<Plumbing />} />
              <Route path="/products/sand" element={<Sand />} />
              <Route path="/franchisePage" element={<FranchisePage />} /> {/* Updated path */}
              <Route path="/suppliers/list" element={<SupplierList />} />
              <Route path="/suppliers/profile" element={<SupplierProfilePage />} />
              <Route path="/products/cement" element={<Cement />} />
              <Route path="/suppliers/manage" element={<AddSupplierPage />} />
              <Route path="/suppliers/Reviews" element={<ReviewsAndRatings />} /> {/* Correct path format for dynamic params */}
              {/* <Route path="/product/:id" element={<ProductDetail products={products} />} /> */}
              

            </Routes>
          </main>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;

import React, { useEffect, useState } from 'react';
import notificationService from '../services/notificationService';
import '../styles/Notification.css';

const NotificationComponent = () => {
  const [notification, setNotification] = useState(null);
  const [token, setToken] = useState(null);

  useEffect(() => {
    const requestPermissionAndToken = async () => {
      try {
        const fcmToken = await notificationService.requestPermission();
        setToken(fcmToken);
        
        // Send token to backend
        await fetch('http://localhost:3001/api/notifications/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ token: fcmToken }),
        });
      } catch (error) {
        console.error('Error requesting permission:', error);
      }
    };

    requestPermissionAndToken();
  }, []);

  useEffect(() => {
    if (token) {
      const unsubscribe = notificationService.onMessageListener()
        .then((payload) => {
          setNotification({
            title: payload.notification.title,
            body: payload.notification.body,
          });

          // Auto-hide notification after 5 seconds
          setTimeout(() => {
            setNotification(null);
          }, 5000);
        })
        .catch((err) => console.error('Error receiving message:', err));

      return () => unsubscribe;
    }
  }, [token]);

  if (!notification) return null;

  return (
    <div className="notification-container">
      <div className="notification">
        <h4>{notification.title}</h4>
        <p>{notification.body}</p>
        <button 
          className="close-button"
          onClick={() => setNotification(null)}
        >
          ×
        </button>
      </div>
    </div>
  );
};

export default NotificationComponent;

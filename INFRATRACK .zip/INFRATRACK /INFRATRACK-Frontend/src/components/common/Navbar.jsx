import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';

const Nav = styled(motion.nav)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(10px);
  padding: 1rem 2rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);

  @media (max-width: 768px) {
    padding: 1rem;
    flex-direction: column;
    gap: 1rem;
  }
`;

const Logo = styled(Link)`
  text-decoration: none;
  display: flex;
  align-items: center;
  padding: 0.5rem;

  img {
    height: 35px;
    width: auto;
  }
`;

const NavLinks = styled.div`
  display: flex;
  align-items: center;
  gap: 2rem;

  @media (max-width: 768px) {
    flex-wrap: wrap;
    justify-content: center;
    gap: 1rem;
  }
`;

const NavLink = styled(Link)`
  color: ${(props) => props.theme.text};
  text-decoration: none;
  font-weight: 500;
  font-size: 0.95rem;
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 25px;
  transition: all 0.3s ease;
  white-space: nowrap;

  &:hover {
    color: ${(props) => props.theme.primary};
    background: rgba(37, 99, 235, 0.1);
  }

  &.active {
    color: ${(props) => props.theme.primary};
    background: rgba(37, 99, 235, 0.1);
    font-weight: 600;
  }
`;

const DropdownMenu = styled(motion.div)`
  position: absolute;
  top: 100%;
  left: 0;
  background: white;
  padding: 0.5rem 0;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  min-width: 200px;
  z-index: 1000;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-10px);
  transition: all 0.3s ease;

  a {
    display: block;
    padding: 0.5rem 1rem;
    color: ${(props) => props.theme.text};
    text-decoration: none;
    font-size: 0.95rem;
    transition: background 0.3s ease;

    &:hover {
      background: rgba(37, 99, 235, 0.1);
      color: ${(props) => props.theme.primary};
    }
  }
`;

const Dropdown = styled.div`
  position: relative;
  
  &:hover > ${DropdownMenu} {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
  }
`;

const RightSection = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;

  @media (max-width: 768px) {
    width: 100%;
    justify-content: center;
  }
`;

const CartButton = styled(Link)`
  background: rgba(37, 99, 235, 0.1);
  color: ${(props) => props.theme.primary};
  padding: 0.5rem 1.2rem;
  border-radius: 25px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  text-decoration: none;
  font-size: 0.95rem;
  transition: all 0.3s ease;

  &:hover {
    background: rgba(37, 99, 235, 0.2);
    transform: translateY(-2px);
  }
`;

const SignUpButton = styled(Link)`
  background: ${(props) => props.theme.primary};
  color: white;
  padding: 0.5rem 1.2rem;
  border-radius: 25px;
  font-weight: 600;
  text-decoration: none;
  font-size: 0.95rem;
  transition: all 0.3s ease;

  &:hover {
    background: ${(props) => props.theme.primaryDark};
    transform: translateY(-2px);
  }
`;

const Navbar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState('');
  const location = useLocation();

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Franchise', path: '/franchisePage' },
    { name: 'About', path: '/about' },
  ];

  const suppliersPages = [
    { name: 'Suppliers List', path: '/suppliers/list' },
    { name: 'Supplier Profile', path: '/suppliers/profile' },
    { name: 'Add/Manage Suppliers', path: '/suppliers/manage' },
    { name: 'Reviews and Ratings', path: '/suppliers/reviews' },
  ];

  const productCategories = [
    { name: 'Tile', path: '/products/tile' },
    { name: 'Steel', path: '/products/steel' },
    { name: 'Wood', path: '/products/wood' },
    { name: 'Plumbing', path: '/products/plumbing' },
    { name: 'Cement', path: '/products/cement' },
    { name: 'Sand', path: '/products/sand' },
  ];

  return (
    <Nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{
        type: 'spring',
        stiffness: 260,
        damping: 20,
      }}
    >
      <Logo to="/">
        <img src="/infratrack-logo.svg" alt="INFRATRACK" />
      </Logo>

      <NavLinks>
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={location.pathname === item.path ? 'active' : ''}
          >
            {item.name}
          </NavLink>
        ))}

        <Dropdown>
          <NavLink as="div">Suppliers</NavLink>
          <DropdownMenu>
            {suppliersPages.map((page) => (
              <Link key={page.name} to={page.path}>
                {page.name}
              </Link>
            ))}
          </DropdownMenu>
        </Dropdown>

        <Dropdown>
          <NavLink as="div">New Products</NavLink>
          <DropdownMenu>
            {productCategories.map((category) => (
              <Link key={category.name} to={category.path}>
                {category.name}
              </Link>
            ))}
          </DropdownMenu>
        </Dropdown>
      </NavLinks>

      <RightSection>
        <CartButton to="/cart">
          <FaShoppingCart size={18} />
          Cart
        </CartButton>
        <SignUpButton to="/signup">Sign Up</SignUpButton>
      </RightSection>
    </Nav>
  );
};

export default Navbar;

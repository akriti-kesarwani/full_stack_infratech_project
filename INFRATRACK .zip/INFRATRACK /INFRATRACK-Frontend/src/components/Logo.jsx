import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const LogoIcon = styled.div`
  font-size: ${props => props.small ? '2rem' : '2.5rem'};
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  
  &::before {
    content: '◆';
    background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    transform: rotate(0deg);
    transition: transform 0.3s ease;
  }

  &::after {
    content: '▲';
    position: absolute;
    background: linear-gradient(135deg, #60A5FA 0%, #3B82F6 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    transform: rotate(180deg);
    transition: transform 0.3s ease;
  }
`;

const LogoContainer = styled(motion.div)`
  display: flex;
  align-items: center;
  padding: 12px 20px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 1);
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }

  &:hover ${LogoIcon} {
    &::before {
      transform: rotate(-30deg) scale(1.2);
    }
    &::after {
      transform: rotate(210deg) scale(1.2);
    }
  }
`;

const LogoText = styled.div`
  font-size: ${props => props.small ? '1.5rem' : '1.8rem'};
  font-weight: 900;
  letter-spacing: -1px;
  text-transform: uppercase;
  background: ${props => props.isFooter ? 
    'linear-gradient(135deg, #1E293B 0%, #334155 100%)' : 
    'linear-gradient(135deg, #1E293B 0%, #334155 100%)'};
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
  
  span {
    background: linear-gradient(135deg, #60A5FA 0%, #3B82F6 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    font-style: italic;
  }
`;

const Logo = ({ small, isFooter, style }) => {
  const navigate = useNavigate();

  try {
    return (
      <LogoContainer
        style={style}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ 
          opacity: 1, 
          y: 0,
          transition: {
            duration: 0.5,
            ease: "easeOut"
          }
        }}
        data-is-footer={isFooter}
        onClick={() => navigate('/')}
      >
        <LogoIcon 
          small={small}
          as={motion.div}
          animate={{ 
            rotate: [0, 360],
            transition: {
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }
          }}
        />
        <LogoText 
          small={small} 
          isFooter={isFooter}
          as={motion.div}
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: 1,
            transition: {
              delay: 0.2,
              duration: 0.5
            }
          }}
        >
          INFRA<span>TRACK</span>
        </LogoText>
      </LogoContainer>
    );
  } catch (error) {
    console.error('Error rendering Logo:', error);
    return null;
  }
};

Logo.defaultProps = {
  small: false,
  isFooter: false,
  style: {}
};

export default Logo; 
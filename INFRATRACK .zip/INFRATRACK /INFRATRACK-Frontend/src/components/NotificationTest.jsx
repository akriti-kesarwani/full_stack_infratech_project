import React, { useState } from 'react';
import { API_URLS } from '../config/api';

const NotificationTest = () => {
  const [status, setStatus] = useState('');

  const testNotification = async () => {
    try {
      setStatus('Testing...');
      const response = await fetch(`${API_URLS.BASE}/api/health`);
      const data = await response.json();
      setStatus(`Server status: ${data.status}`);
    } catch (error) {
      console.error('Error:', error);
      setStatus('Error: ' + error.message);
    }
  };

  return (
    <div>
      <button onClick={testNotification}>Test Connection</button>
      <p>{status}</p>
    </div>
  );
};

export default NotificationTest;

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import '../styles/ProductCard.css';

const ProductCard = ({ product, category }) => {
  const [loading, setLoading] = useState(false);

  const handleAddToCart = async () => {
    try {
      setLoading(true);
      const response = await axios.post('http://localhost:3001/api/cart/add', {
        productId: product.productId,
        productName: product.name,
        price: product.price,
        quantity: 1,
        category: category,
        brand: product.brand,
        image: product.image
      });

      if (response.data.success) {
        alert('Product added to cart successfully!');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add product to cart');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="product-card">
      <img src={product.image} alt={product.name} className="product-image" />
      <h2 className="product-name">{product.name}</h2>
      <p className="product-brand">Brand: {product.brand}</p>
      <p className="product-price">Price: {product.price} Rs</p>
      <button
        className="add-to-cart-btn"
        onClick={handleAddToCart}
        disabled={loading}
      >
        {loading ? 'Adding...' : 'Add to Cart'}
      </button>
    </div>
  );
};

ProductCard.propTypes = {
  product: PropTypes.shape({
    productId: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    brand: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    image: PropTypes.string.isRequired,
  }).isRequired,
  category: PropTypes.string.isRequired,
};

export default ProductCard;

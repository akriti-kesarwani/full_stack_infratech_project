export const theme = {
  primary: '#2563eb',
  primaryLight: '#60a5fa',
  primaryDark: '#1e40af',
  secondary: '#f43f5e',
  secondaryLight: '#fb7185',
  accent: '#10b981',
  accentLight: '#34d399',
  background: '#f8fafc',
  backgroundDark: '#f1f5f9',
  text: '#0f172a',
  textLight: '#64748b',
  white: '#FFFFFF',
  shadows: {
    small: '0 2px 8px rgba(0,0,0,0.08)',
    medium: '0 4px 12px rgba(0,0,0,0.12)',
    large: '0 8px 24px rgba(0,0,0,0.15)',
    hover: '0 12px 32px rgba(0,0,0,0.18)'
  },
  gradients: {
    primary: 'linear-gradient(135deg, #2563eb 0%, #1e40af 100%)',
    secondary: 'linear-gradient(135deg, #f43f5e 0%, #e11d48 100%)',
    accent: 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
  }
}; 